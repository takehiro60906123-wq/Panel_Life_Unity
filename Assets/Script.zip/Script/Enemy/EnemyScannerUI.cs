using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;

/// <summary>
/// 敵をタッチするとスキャナーパネルで情報表示。
/// 敵の近くに「SCAN」ヒントが常時パルスして、タッチ可能であることを示す。
/// </summary>
public class EnemyScannerUI : MonoBehaviour
{
    [Header("参照")]
    [SerializeField] private PanelBattleManager panelBattleManager;

    [Header("スキャナーパネル")]
    [SerializeField] private RectTransform scannerPanel;
    [SerializeField] private CanvasGroup scannerCanvasGroup;

    [Header("表示テキスト")]
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text typeText;
    [SerializeField] private TMP_Text statsText;
    [SerializeField] private TMP_Text patternText;
    [SerializeField] private TMP_Text adviceText;

    [Header("スキャンライン（任意）")]
    [SerializeField] private RectTransform scanLineImage;

    [Header("スキャンヒント")]
    [Tooltip("敵の近くに表示される常時パルスするワールドスペースのオブジェクト。\n" +
             "SpriteRenderer または Canvas+Text を持つ小さいプレハブ。\n" +
             "なければスクリプトが自動で TextMesh を生成する。")]
    [SerializeField] private GameObject scanHintPrefab;
    [SerializeField] private Vector3 scanHintOffset = new Vector3(0f, 1.8f, 0f);
    [SerializeField] private float scanHintPulseScale = 1.2f;
    [SerializeField] private float scanHintPulseDuration = 0.8f;

    [Header("演出設定")]
    [SerializeField] private float openDuration = 0.25f;
    [SerializeField] private float closeDuration = 0.15f;
    [SerializeField] private float scanLineDuration = 0.4f;
    [SerializeField] private float tapRadius = 160f;

    [Header("色設定")]
    [SerializeField] private Color normalColor = Color.white;
    [SerializeField] private Color floatingColor = new Color(0.6f, 0.9f, 1f);
    [SerializeField] private Color armoredColor = new Color(1f, 0.8f, 0.4f);
    [SerializeField] private Color rushingColor = new Color(1f, 0.5f, 0.5f);
    [SerializeField] private Color rangedColor = new Color(0.8f, 0.6f, 1f);

    private bool isOpen;
    private BattleUnit currentTarget;
    private GameObject scanHintInstance;
    private BattleUnit lastTrackedEnemy;

    private void Awake()
    {
        if (scannerPanel != null)
        {
            scannerPanel.gameObject.SetActive(false);
        }
        isOpen = false;
    }

    private void Update()
    {
        // --- スキャンヒントの追従 ---
        UpdateScanHintPosition();

        if (!Input.GetMouseButtonDown(0)) return;

        if (isOpen)
        {
            CloseScanner();
            return;
        }

        BattleUnit tappedEnemy = DetectEnemyTap();
        if (tappedEnemy != null)
        {
            OpenScanner(tappedEnemy);
        }
    }

    // =============================================================
    // スキャンヒント（常時表示）
    // =============================================================

    private void UpdateScanHintPosition()
    {
        BattleUnit enemy = GetCurrentEnemy();

        // 敵が変わったらヒントを再生成
        if (enemy != lastTrackedEnemy)
        {
            lastTrackedEnemy = enemy;
            DestroyScanHint();

            if (enemy != null && !enemy.IsDead())
            {
                CreateScanHint(enemy);
            }
        }

        // ヒントを敵に追従
        if (scanHintInstance != null && enemy != null && !enemy.IsDead())
        {
            scanHintInstance.transform.position = enemy.transform.position + scanHintOffset;
        }

        // 敵が死んだらヒントを消す
        if (enemy != null && enemy.IsDead())
        {
            DestroyScanHint();
        }
    }

    private void CreateScanHint(BattleUnit enemy)
    {
        if (scanHintPrefab != null)
        {
            scanHintInstance = Instantiate(scanHintPrefab, enemy.transform.position + scanHintOffset, Quaternion.identity);
        }
        else
        {
            // プレハブがなければ自動生成（TextMesh で "SCAN" 表示）
            scanHintInstance = new GameObject("ScanHint");
            scanHintInstance.transform.position = enemy.transform.position + scanHintOffset;

            TextMesh tm = scanHintInstance.AddComponent<TextMesh>();
            tm.text = "SCAN";
            tm.fontSize = 28;
            tm.characterSize = 0.12f;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.color = new Color(0.4f, 0.9f, 1f, 0.8f);

            MeshRenderer mr = scanHintInstance.GetComponent<MeshRenderer>();
            if (mr != null) mr.sortingOrder = 100;
        }

        // パルスアニメーション
        if (scanHintInstance != null)
        {
            scanHintInstance.transform.localScale = Vector3.one;
            scanHintInstance.transform
                .DOScale(Vector3.one * scanHintPulseScale, scanHintPulseDuration)
                .SetEase(Ease.InOutSine)
                .SetLoops(-1, LoopType.Yoyo);
        }
    }

    private void DestroyScanHint()
    {
        if (scanHintInstance != null)
        {
            scanHintInstance.transform.DOKill();
            Destroy(scanHintInstance);
            scanHintInstance = null;
        }
    }

    private void OnDestroy()
    {
        DestroyScanHint();
    }

    // =============================================================
    // タップ検出
    // =============================================================

    private BattleUnit DetectEnemyTap()
    {
        BattleUnit enemyUnit = GetCurrentEnemy();
        if (enemyUnit == null || enemyUnit.IsDead()) return null;

        Vector2 screenPos = Input.mousePosition;
        Camera mainCam = Camera.main;
        if (mainCam == null) return null;

        Vector3 enemyWorldPos = enemyUnit.transform.position + Vector3.up * 0.75f;
        Renderer enemyRenderer = enemyUnit.GetComponentInChildren<Renderer>();
        if (enemyRenderer != null)
        {
            enemyWorldPos = enemyRenderer.bounds.center;
        }

        Vector2 enemyScreenPos = RectTransformUtility.WorldToScreenPoint(mainCam, enemyWorldPos);

        if (Vector2.Distance(screenPos, enemyScreenPos) <= tapRadius)
        {
            return enemyUnit;
        }

        return null;
    }

    private BattleUnit GetCurrentEnemy()
    {
        if (panelBattleManager != null)
        {
            return panelBattleManager.enemyUnit;
        }
        return null;
    }

    // =============================================================
    // スキャナー開閉
    // =============================================================

    private void OpenScanner(BattleUnit enemy)
    {
        if (scannerPanel == null || enemy == null) return;

        currentTarget = enemy;
        isOpen = true;

        SetScannerTexts(enemy);

        scannerPanel.gameObject.SetActive(true);
        scannerPanel.localScale = new Vector3(1f, 0f, 1f);

        if (scannerCanvasGroup != null) scannerCanvasGroup.alpha = 0f;

        Sequence seq = DOTween.Sequence();
        seq.Append(scannerPanel.DOScaleY(1f, openDuration).SetEase(Ease.OutBack));

        if (scannerCanvasGroup != null)
            seq.Join(scannerCanvasGroup.DOFade(1f, openDuration));

        if (scanLineImage != null)
        {
            scanLineImage.gameObject.SetActive(true);
            float panelHeight = scannerPanel.rect.height;
            scanLineImage.anchoredPosition = new Vector2(0, panelHeight * 0.5f);
            seq.Append(scanLineImage.DOAnchorPosY(-panelHeight * 0.5f, scanLineDuration).SetEase(Ease.Linear));
            seq.AppendCallback(() => { if (scanLineImage != null) scanLineImage.gameObject.SetActive(false); });
        }
    }

    private void CloseScanner()
    {
        if (scannerPanel == null) return;

        isOpen = false;
        currentTarget = null;

        Sequence seq = DOTween.Sequence();
        if (scannerCanvasGroup != null)
            seq.Append(scannerCanvasGroup.DOFade(0f, closeDuration));
        seq.Join(scannerPanel.DOScaleY(0f, closeDuration).SetEase(Ease.InBack));
        seq.OnComplete(() => { if (scannerPanel != null) scannerPanel.gameObject.SetActive(false); });
    }

    // =============================================================
    // テキスト生成
    // =============================================================

    private void SetScannerTexts(BattleUnit enemy)
    {
        if (enemy == null) return;

        Color typeColor = GetTypeColor(enemy.enemyType);

        if (nameText != null)
        {
            string lvStr = enemy.enemyLevel > 0 ? $"  Lv+{enemy.enemyLevel}" : "";
            nameText.text = $"[ SCAN ] {enemy.name.Replace("(Clone)", "")}{lvStr}";
        }

        if (typeText != null)
        {
            typeText.text = GetTypeLabel(enemy.enemyType);
            typeText.color = typeColor;
        }

        if (statsText != null)
        {
            string intervalStr = enemy.attackInterval <= 1 ? "EVERY TURN" : $"EVERY {enemy.attackInterval} TURNS";
            statsText.text = $"HP {enemy.CurrentHP}/{enemy.maxHP}    ATK {enemy.attackPower}    {intervalStr}    EXP {enemy.expYield}";
        }

        if (patternText != null)
            patternText.text = GetPatternLabel(enemy.attackPattern, enemy.attackPower);

        if (adviceText != null)
        {
            adviceText.text = GetAdviceText(enemy.enemyType, enemy.attackPattern);
            adviceText.color = typeColor;
        }
    }

    private string GetTypeLabel(EnemyType type)
    {
        switch (type)
        {
            case EnemyType.Floating: return "TYPE: FLOATING";
            case EnemyType.Armored: return "TYPE: ARMORED";
            case EnemyType.Rushing: return "TYPE: RUSHING";
            case EnemyType.Ranged: return "TYPE: RANGED";
            default: return "TYPE: NORMAL";
        }
    }

    private Color GetTypeColor(EnemyType type)
    {
        switch (type)
        {
            case EnemyType.Floating: return floatingColor;
            case EnemyType.Armored: return armoredColor;
            case EnemyType.Rushing: return rushingColor;
            case EnemyType.Ranged: return rangedColor;
            default: return normalColor;
        }
    }

    private string GetPatternLabel(EnemyAttackPattern pattern, int atk)
    {
        switch (pattern)
        {
            case EnemyAttackPattern.HeavyHit:
                return $"SKILL: Heavy Hit — 1 turn charge, then {atk * 2} damage";
            case EnemyAttackPattern.MultiHit:
                return $"SKILL: Multi Hit — {atk} x 2 strikes";
            case EnemyAttackPattern.SelfBuff:
                return $"SKILL: Self Repair — sometimes heals +{atk * 2}";
            case EnemyAttackPattern.PanelCorrupt:
                return atk > 0
                    ? $"SKILL: Panel Corrupt — ATK {atk} + contaminates board"
                    : "SKILL: Panel Corrupt — contaminates board only";
            default:
                return $"ATK: {atk}";
        }
    }

    private string GetAdviceText(EnemyType type, EnemyAttackPattern pattern)
    {
        string typeAdvice = GetTypeAdvice(type);
        string patternAdvice = GetPatternAdvice(pattern);

        if (!string.IsNullOrEmpty(typeAdvice) && !string.IsNullOrEmpty(patternAdvice))
            return $"{typeAdvice}\n{patternAdvice}";
        if (!string.IsNullOrEmpty(typeAdvice)) return typeAdvice;
        if (!string.IsNullOrEmpty(patternAdvice)) return patternAdvice;
        return "";
    }

    private string GetTypeAdvice(EnemyType type)
    {
        switch (type)
        {
            case EnemyType.Floating: return "> Melee damage halved. Use guns.";
            case EnemyType.Armored: return "> Reduces small damage. Use high single hits.";
            case EnemyType.Rushing: return "> Attacks every turn. Prioritize elimination.";
            case EnemyType.Ranged: return "> Ranged attacker. Eliminate quickly.";
            default: return "";
        }
    }

    private string GetPatternAdvice(EnemyAttackPattern pattern)
    {
        switch (pattern)
        {
            case EnemyAttackPattern.HeavyHit: return "> Kill during charge turn for safety.";
            case EnemyAttackPattern.MultiHit: return "> Multiple hits per turn. Keep HP high.";
            case EnemyAttackPattern.SelfBuff: return "> Heals if left alone. Push damage fast.";
            case EnemyAttackPattern.PanelCorrupt: return "> Corrupts board with LvUp panels.";
            default: return "";
        }
    }
}