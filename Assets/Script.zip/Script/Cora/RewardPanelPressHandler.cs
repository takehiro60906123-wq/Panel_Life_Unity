using System;
using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

public class RewardPanelPressHandler : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
{
    [SerializeField] private float longPressSeconds = 0.45f;

    private int row;
    private int col;
    private Action<int, int> onLongPress;
    private Coroutine longPressRoutine;
    private bool longPressTriggered;

    public void Configure(int row, int col, Action<int, int> onLongPress)
    {
        this.row = row;
        this.col = col;
        this.onLongPress = onLongPress;
        enabled = onLongPress != null;
    }

    public bool ConsumeSuppressClick()
    {
        bool result = longPressTriggered;
        longPressTriggered = false;
        return result;
    }

    public void Clear()
    {
        if (longPressRoutine != null)
        {
            StopCoroutine(longPressRoutine);
            longPressRoutine = null;
        }

        onLongPress = null;
        longPressTriggered = false;
        enabled = false;
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (onLongPress == null) return;

        longPressTriggered = false;
        if (longPressRoutine != null)
        {
            StopCoroutine(longPressRoutine);
        }

        longPressRoutine = StartCoroutine(LongPressRoutine());
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        CancelLongPress();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        CancelLongPress();
    }

    private IEnumerator LongPressRoutine()
    {
        yield return new WaitForSeconds(longPressSeconds);
        longPressTriggered = true;
        onLongPress?.Invoke(row, col);
        longPressRoutine = null;
    }

    private void CancelLongPress()
    {
        if (longPressRoutine != null)
        {
            StopCoroutine(longPressRoutine);
            longPressRoutine = null;
        }
    }
}
