using System.Collections.Generic;
using UnityEngine;

public class StageFlowController : MonoBehaviour
{
    public struct NextEncounterPlan
    {
        public bool isStageClear;
        public EncounterType encounterType;
        public int steps;

        public NextEncounterPlan(bool clear, EncounterType type, int stepCount)
        {
            isStageClear = clear;
            encounterType = type;
            steps = stepCount;
        }
    }

    private Transform battlePosition;
    private Vector3 waitOffset;
    private int maxFloors;
    private int maxVisibleEnemies;
    private List<BattleUnit> enemyPrefabs;

    // --- Tier �Ή� ---
    private StageConfig stageConfig;

    private readonly Queue<BattleUnit> upcomingEnemies = new Queue<BattleUnit>();
    private int spawnedEnemyCount = 0;

    private int defeatedEnemyCount = 0;
    public int DefeatedEnemyCount => defeatedEnemyCount;
    public int TotalBattles => maxFloors;

    /// <summary>
    /// ���݂̐퓬�ԍ��i1�n�܂�j�BTier ����Ɏg�p�B
    /// </summary>
    public int CurrentBattleNumber => spawnedEnemyCount;

    public void Configure(
        Transform battlePositionValue,
        Vector3 waitOffsetValue,
        int maxFloorsValue,
        int maxVisibleEnemiesValue,
        List<BattleUnit> enemyPrefabsValue)
    {
        battlePosition = battlePositionValue;
        waitOffset = waitOffsetValue;
        maxFloors = maxFloorsValue;
        maxVisibleEnemies = maxVisibleEnemiesValue;
        enemyPrefabs = enemyPrefabsValue;
    }

    /// <summary>
    /// StageConfig ��ݒ肷��B�ݒ肷��� Tier �x�[�X�̓G�I�o���L���ɂȂ�B
    /// Configure() �̌�ɌĂԁB
    /// </summary>
    public void SetStageConfig(StageConfig config)
    {
        stageConfig = config;

        if (stageConfig != null && stageConfig.totalBattles > 0)
        {
            maxFloors = stageConfig.totalBattles;
        }
    }

    public bool SetupInitialStage(out BattleUnit currentEnemy, out string errorMessage)
    {
        defeatedEnemyCount = 0;
        currentEnemy = null;
        errorMessage = string.Empty;

        if (!ValidateConfiguration(out errorMessage))
        {
            return false;
        }

        upcomingEnemies.Clear();
        spawnedEnemyCount = 0;

        int initialSpawnCount = Mathf.Min(maxVisibleEnemies, maxFloors);
        for (int i = 0; i < initialSpawnCount; i++)
        {
            SpawnNextEnemyInternal();
        }

        if (upcomingEnemies.Count <= 0)
        {
            errorMessage = "�����ł���G�����܂���ł����B";
            return false;
        }

        currentEnemy = upcomingEnemies.Dequeue();
        return true;
    }

    public IEnumerable<BattleUnit> GetUpcomingEnemies()
    {
        return upcomingEnemies;
    }

    public BattleUnit DequeueNextEnemy()
    {
        if (upcomingEnemies.Count <= 0) return null;
        return upcomingEnemies.Dequeue();
    }

    public void SpawnNextEnemyIfPossible()
    {
        if (!ValidateConfiguration(out _)) return;
        SpawnNextEnemyInternal();
    }

    public void SpawnNextEnemyAfter(Vector3 anchorPosition)
    {
        if (!ValidateConfiguration(out _)) return;
        if (spawnedEnemyCount >= maxFloors) return;

        BattleUnit prefabToSpawn = PickEnemyPrefab();
        if (prefabToSpawn == null) return;

        Vector3 spawnPos = anchorPosition + waitOffset;

        BattleUnit lastQueuedEnemy = null;
        foreach (BattleUnit enemy in upcomingEnemies)
        {
            if (enemy != null)
            {
                lastQueuedEnemy = enemy;
            }
        }

        if (lastQueuedEnemy != null)
        {
            spawnPos = lastQueuedEnemy.transform.position + waitOffset;
        }

        BattleUnit newEnemy = Instantiate(prefabToSpawn, spawnPos, Quaternion.identity);
        upcomingEnemies.Enqueue(newEnemy);
        spawnedEnemyCount++;
    }

    public NextEncounterPlan DecideNextEncounter(EncounterType previousEncounter)
    {
        if (IsStageClear())
        {
            return new NextEncounterPlan(true, EncounterType.Enemy, 0);
        }

        bool forceEnemy = previousEncounter == EncounterType.Empty || previousEncounter == EncounterType.Treasure;
        int roll = forceEnemy ? 0 : Random.Range(0, 100);

        if (forceEnemy || roll < 70)
        {
            return new NextEncounterPlan(false, EncounterType.Enemy, 0);
        }

        if (roll < 90)
        {
            return new NextEncounterPlan(false, EncounterType.Empty, 3);
        }

        return new NextEncounterPlan(false, EncounterType.Treasure, 1);
    }

    private bool IsStageClear()
    {
        return upcomingEnemies.Count == 0 && spawnedEnemyCount >= maxFloors;
    }

    private bool ValidateConfiguration(out string errorMessage)
    {
        errorMessage = string.Empty;

        // StageConfig ������ꍇ�͂�����̓G�v�[�����g��
        bool hasStageConfig = stageConfig != null
            && stageConfig.tiers != null
            && stageConfig.tiers.Count > 0;

        bool hasLegacyPrefabs = enemyPrefabs != null && enemyPrefabs.Count > 0;

        if (!hasStageConfig && !hasLegacyPrefabs)
        {
            errorMessage = "enemyPrefabs �����ݒ�ł��B�G�v���n�u��1�ȏ�o�^���Ă��������B";
            return false;
        }

        if (battlePosition == null)
        {
            errorMessage = "battlePosition �����ݒ�ł��B";
            return false;
        }

        if (maxFloors <= 0)
        {
            errorMessage = "maxFloors �� 0 �ȉ��ł��B";
            return false;
        }

        return true;
    }

    private void SpawnNextEnemyInternal()
    {
        if (spawnedEnemyCount >= maxFloors) return;
        if (battlePosition == null) return;

        BattleUnit prefabToSpawn = PickEnemyPrefab();
        if (prefabToSpawn == null) return;

        Vector3 spawnPos = battlePosition.position + (waitOffset * spawnedEnemyCount);

        BattleUnit newEnemy = Instantiate(prefabToSpawn, spawnPos, Quaternion.identity);
        upcomingEnemies.Enqueue(newEnemy);
        spawnedEnemyCount++;
    }

    /// <summary>
    /// StageConfig ������� Tier ����I�o�A�Ȃ���Ώ]���̃����_���B
    /// </summary>
    private BattleUnit PickEnemyPrefab()
    {
        // Tier �x�[�X�iStageConfig ����j
        if (stageConfig != null && stageConfig.tiers != null && stageConfig.tiers.Count > 0)
        {
            int battleNumber = spawnedEnemyCount + 1;
            BattleUnit picked = stageConfig.PickEnemyPrefab(battleNumber);
            if (picked != null) return picked;
        }

        // �t�H�[���o�b�N�F�]���̃����_���I�o
        if (enemyPrefabs != null && enemyPrefabs.Count > 0)
        {
            return enemyPrefabs[Random.Range(0, enemyPrefabs.Count)];
        }

        return null;
    }

    public BattleUnit TakeNextEnemyOrSpawn(Vector3 anchorPosition)
    {
        if (upcomingEnemies.Count == 0 && spawnedEnemyCount < maxFloors)
        {
            SpawnNextEnemyAfter(anchorPosition);
        }

        if (upcomingEnemies.Count > 0)
        {
            return upcomingEnemies.Dequeue();
        }
        defeatedEnemyCount++;
        return null;
    }

    public bool IsStageComplete()
    {
        return upcomingEnemies.Count == 0 && spawnedEnemyCount >= maxFloors;
    }
}