﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using TMPro;
using UnityEngine.SceneManagement;

public enum PanelType { Sword = 0, Ammo = 1, Coin = 2, Heal = 3, LvUp = 4, Chick = 5, Diamond = 6, Monster = 7, None = 8, Corrupt = 9 }

public enum EncounterType
{
    Enemy,
    Empty,
    Treasure,
    Shop
}

[System.Serializable]
public class PanelSetting
{
    public string label;
    public PanelType type;
    public Sprite panelImage;
    public int weight;
}

public class PanelBattleManager : MonoBehaviour
{
    [Header("UIの設定")]
    public GameObject panelPrefab;
    public Transform boardParent;
    public List<PanelSetting> panelSettings;

    [Header("UIコントローラー")]
    public BattleUIController battleUIController;

    [Header("霞コントローラー")]
    public DungeonMistController dungeonMistController;

    [Header("敵演出コントローラー")]
    public EnemyPresentationController enemyPresentationController;

    [Header("移動演出コントローラー")]
    public RoomTravelController roomTravelController;

    [Header("盤面コントローラー")]
    public PanelBoardController panelBoardController;

    [Header("バトルエフェクトコントローラー")]
    public BattleEffectController battleEffectController;

    [Header("ステージ進行コントローラー")]
    public StageFlowController stageFlowController;
    [SerializeField] private BattleBackgroundThemeController battleBackgroundThemeController;

    [Header("ターン進行コントローラー")]
    public BattleTurnController battleTurnController;

    [Header("パネル行動コントローラー")]
    public PanelActionController panelActionController;

    [Header("戦闘進行コントローラー")]
    public EncounterFlowController encounterFlowController;

    [Header("商店コントローラー")]
    public ShopController shopController;

    [Header("報酬ドロップコントローラー")]
    public RewardDropController rewardDropController;

    [Header("ダメージ解決コントローラー")]
    public BattleDamageResolver battleDamageResolver;

    [Header("銃戦闘コントローラー")]
    public GunCombatController gunCombatController;

    [Header("初期化コントローラー")]
    public BattleBootstrapper battleBootstrapper;

    [Header("ステージ入場演出コントローラー")]
    public StageIntroController stageIntroController;

    [Header("ボス登場演出コントローラー")]
    public BossIntroController bossIntroController;

    [Header("アイテムアイコンDB")]
    public BattleItemIconDatabase battleItemIconDatabase;

    [Header("ゲーム開始演出")]
    [SerializeField] private bool playGameStartIntro = true;
    public bool ShouldPlayGameStartIntro => playGameStartIntro
        && stageIntroController != null
        && stageIntroController.ShouldPlayOnGameStart;

    [Header("イベントハブ")]
    public BattleEventHub battleEventHub;

    [Header("バトルユニット連携")]
    public BattleUnit playerUnit;

    [Header("状態コンテキスト")]
    [SerializeField] private BattleContext battleContext;

    public BattleContext Context => battleContext;

    [SerializeField] private PlayerCombatLoadout playerLoadout;
    [SerializeField] private PlayerCombatController playerCombatController;
    public PlayerCombatController PlayerCombatController => playerCombatController;
    public GunCombatController GunCombatController => gunCombatController;

    [Header("プレイヤー強化演出")]
    [SerializeField] private PlayerPowerupFeedbackPresenter playerPowerupFeedbackPresenter;
    private bool powerupFeedbackEventsSubscribed;

    [Header("状態異常")]
    [SerializeField] private float paralysisSkipDelay = 0.6f;
    private bool paralysisSkipRunning;

    [Header("アイテム設定")]
    [SerializeField] private BattleInventoryController battleInventoryController;
    [SerializeField] private float itemUseDelay = 0.08f;
    [SerializeField, Range(0f, 1f)] private float enemyItemDropChance = 0.35f;
    [SerializeField] private List<BattleItemDropEntry> itemDropEntries = new List<BattleItemDropEntry>();
    [SerializeField] private int scrapOnOverflow = 1;
    [SerializeField] private int currentScrap;
    [SerializeField] private float enemyItemDragDropRadius = 140f;

    [SerializeField, Range(1f, 1.5f)] private float enemyDragHoverScale = 1.08f;
    [SerializeField] private Color enemyDragHoverColor = new Color(1f, 0.95f, 0.8f, 1f);

    [Header("アイテム付きパネル設定")]
    [SerializeField, Range(0f, 1f)] private float panelItemSpawnChanceNormal = 0.35f;
    [SerializeField] private List<int> guaranteedPanelItemBattleNumbers = new List<int> { 10, 20, 25 };

    [Header("持続アイテム設定")]
    [SerializeField, Min(1)] private int attackOilDefaultDurationTurns = 3;
    [SerializeField, Range(0f, 1f)] private float attackOilDamageBonusRate = 0.25f;

    private int playerDamageBoostTurnsRemaining;
    private float playerDamageBoostRate;
    private bool skipNextPlayerBuffDecrement;

    private bool defeatSequenceRunning;
    [SerializeField] private float defeatSequenceStartDelay = 0.06f;
    [SerializeField] private float dropFeedbackHoldDelay = 0.18f;
    [SerializeField] private float defeatSequenceBeforeRewardDelay = 0.06f;
    [SerializeField] private float defeatSequenceAfterRewardDelay = 0.10f;

    [SerializeField] private PlayerProgression playerProgression;

    [Header("Home帰還設定")]
    [SerializeField] private string homeSceneName = "Home";
    [SerializeField] private bool returnToHomeOnGameOver = true;
    [SerializeField] private bool returnToHomeOnStageClear = true;
    [SerializeField] private bool useEndingSceneOnFinalClear = true;
    [SerializeField] private string endingSceneName = "Ending";
    [SerializeField] private float resultMessageHoldDuration = 1.0f;
    [SerializeField] private float resultTextFadeDuration = 0.18f;
    [SerializeField] private float resultFadeDuration = 0.45f;
    [SerializeField] private Color stageClearResultTextColor = new Color(1f, 0.95f, 0.78f, 1f);
    [SerializeField] private Color gameOverResultTextColor = new Color(1f, 0.42f, 0.42f, 1f);
    [SerializeField] private TMP_Text resultMessageText;
    [SerializeField] private CanvasGroup resultMessageCanvasGroup;
    [SerializeField] private Image resultFadeOverlay;
    private bool resultReturnSequenceRunning;

    [Header("背景テーマ切替演出")]
    [SerializeField] private bool enableThemeChangeFadeTransition = true;
    [SerializeField] private float themeChangePlayerExitDuration = 0.22f;
    [SerializeField] private float themeChangePlayerEntryDuration = 0.26f;
    [SerializeField] private float themeChangeFadeOutDuration = 0.12f;
    [SerializeField] private float themeChangeFadeHoldDuration = 0.02f;
    [SerializeField] private float themeChangeFadeInDuration = 0.12f;
    [SerializeField, Range(1.02f, 1.4f)] private float themeChangeExitViewportX = 1.12f;
    [SerializeField, Range(-0.4f, -0.02f)] private float themeChangeEntryViewportX = -0.12f;
    [SerializeField, Range(0f, 1f)] private float themeChangePlayerViewportY = 0.24f;
    [SerializeField, Range(0f, 1f)] private float themeChangePlayerEntryViewportY = 0.15f;
    [SerializeField] private Image themeChangeFadeOverlay;

    [Header("エピローグコントローラー")]
    public EpilogueController epilogueController;


    private struct PendingDropFeedback
    {
        public bool hasDrop;
        public bool overflow;
        public int slotIndex;
        public int scrapAmount;
        public string itemName;
        public Vector3 worldPos;
    }

    private PendingDropFeedback pendingDropFeedback;

    private bool enemyDragHoverActive;
    private Vector3 enemyDragHoverOriginalScale = Vector3.one;
    private BattleUnit enemyDragHoverTarget;

    public BattleInventoryController GetBattleInventoryController()
    {
        return battleInventoryController;
    }

    private void EnsureInventoryController()
    {
        if (battleInventoryController == null)
        {
            battleInventoryController = GetComponent<BattleInventoryController>();
        }

        if (battleInventoryController == null)
        {
            battleInventoryController = gameObject.AddComponent<BattleInventoryController>();
        }
    }

    public BattleItemData CreateBattleItem(BattleItemType itemType)
    {
        if (battleItemIconDatabase != null)
        {
            BattleItemData itemWithIcon = battleItemIconDatabase.CreatePreset(itemType);
            if (itemWithIcon != null)
            {
                return itemWithIcon;
            }
        }

        return BattleItemData.CreatePreset(itemType);
    }

    private void EnsureDefaultItemDrops()
    {
        if (itemDropEntries != null && itemDropEntries.Count > 0)
        {
            SanitizeCoinlessItemDrops();
            return;
        }

        itemDropEntries = new List<BattleItemDropEntry>
    {
        new BattleItemDropEntry { itemType = BattleItemType.FieldBandage, weight = 34 },
        new BattleItemDropEntry { itemType = BattleItemType.ShockCanister, weight = 26 },
        new BattleItemDropEntry { itemType = BattleItemType.ActivationCell, weight = 24 },
        new BattleItemDropEntry { itemType = BattleItemType.AttackOil, weight = 16 }
    };

        SanitizeCoinlessItemDrops();
    }

    private void SanitizeCoinlessItemDrops()
    {
        if (!disableCoinPanels || itemDropEntries == null) return;

        itemDropEntries.RemoveAll(entry => entry != null && entry.itemType == BattleItemType.MagneticCollectorCanister);
    }

    public void PrepareItemPanelForCurrentBattle()
    {
        if (panelBoardController == null)
        {
            return;
        }

        panelBoardController.ClearAllAttachedItems();

        if (currentEncounter != EncounterType.Enemy)
        {
            return;
        }

        int battleNumber = 0;
        if (stageFlowController != null)
        {
            battleNumber = enemyUnit != null
                ? stageFlowController.DefeatedEnemyCount + 1
                : stageFlowController.DefeatedEnemyCount;
        }

        if (battleNumber <= 0)
        {
            return;
        }

        bool guaranteed = guaranteedPanelItemBattleNumbers != null
            && guaranteedPanelItemBattleNumbers.Contains(battleNumber);

        float chance = guaranteed ? 1f : panelItemSpawnChanceNormal;
        panelBoardController.TrySpawnAttachedItemPanel(chance);
    }

    public void HandleCollectedPanelItems(List<CollectedPanelItemInfo> collectedItems)
    {
        if (collectedItems == null || collectedItems.Count == 0)
        {
            return;
        }

        for (int i = 0; i < collectedItems.Count; i++)
        {
            CollectedPanelItemInfo info = collectedItems[i];
            if (info == null || info.item == null)
            {
                continue;
            }

            int slotIndexBeforeAdd = battleInventoryController != null
                ? battleInventoryController.Count : -1;

            if (battleInventoryController != null && battleInventoryController.TryAddItem(info.item))
            {
                SpawnDamageText($"ITEM GET!\n{info.item.itemName}", info.worldPosition + Vector3.up * 1.2f, new Color(1f, 0.9f, 0.25f));

                // ★ 飛行オーブ演出（パネル位置 → インベントリスロット）
                Vector3 targetPos = Vector3.zero;
                if (battleUIController != null)
                {
                    targetPos = battleUIController.GetInventorySlotWorldPosition(slotIndexBeforeAdd);
                }

                int capturedSlotIndex = slotIndexBeforeAdd;

                if (battleEffectController != null && targetPos != Vector3.zero)
                {
                    battleEffectController.SpawnItemGetOrb(
                        energyOrbPrefab,
                        absorbEffectPrefab,
                        info.worldPosition + Vector3.up * 0.4f,
                        targetPos,
                        0.4f,
                        () =>
                        {
                            battleUIController?.PlayInventorySlotReceivePulse(capturedSlotIndex);
                            battleUIController?.RefreshInventoryUI();
                        });
                }
                else
                {
                    // フォールバック（飛行先が取れない場合は従来演出）
                    if (absorbEffectPrefab != null)
                    {
                        SpawnOneShotEffect(absorbEffectPrefab, info.worldPosition + Vector3.up * 0.4f, 0.55f);
                    }
                }
            }
            else
            {
                int addedScrap = Mathf.Max(0, scrapOnOverflow);
                currentScrap += addedScrap;
                SpawnDamageText($"ITEM LOST\nSCRAP +{addedScrap}", info.worldPosition + Vector3.up * 1.2f, new Color(0.85f, 0.85f, 0.85f));
            }
        }

        battleUIController?.RefreshInventoryUI();
    }

    public int ApplyPlayerDamageModifiers(int baseDamage)
    {
        if (baseDamage <= 0)
        {
            return 0;
        }

        float multiplier = 1f;
        if (playerDamageBoostTurnsRemaining > 0)
        {
            multiplier += Mathf.Max(0f, playerDamageBoostRate);
        }

        return Mathf.Max(1, Mathf.RoundToInt(baseDamage * multiplier));
    }

    private void ApplyAttackOilBuff(BattleItemData item)
    {
        int duration = item != null && item.durationTurns > 0
            ? item.durationTurns
            : attackOilDefaultDurationTurns;

        float bonusRate = item != null && item.power > 0
            ? item.power / 100f
            : attackOilDamageBonusRate;

        playerDamageBoostTurnsRemaining = Mathf.Max(1, duration);
        playerDamageBoostRate = Mathf.Max(0f, bonusRate);
        skipNextPlayerBuffDecrement = true;
    }

    private void TickPlayerTimedBuffsOnTurnEnd()
    {
        if (playerDamageBoostTurnsRemaining <= 0)
        {
            return;
        }

        if (skipNextPlayerBuffDecrement)
        {
            skipNextPlayerBuffDecrement = false;
            return;
        }

        playerDamageBoostTurnsRemaining--;
        if (playerDamageBoostTurnsRemaining <= 0)
        {
            playerDamageBoostTurnsRemaining = 0;
            playerDamageBoostRate = 0f;
        }
    }

    /// <summary>
    /// 敵のパッシブ状態異常（腐食など）のターン消費。
    /// プレイヤーターン終了時に呼ぶ。
    /// 将来パッシブ効果が増えたらここに足す。
    /// </summary>
    private void TickEnemyPassiveEffectsOnPlayerTurnEnd()
    {
        BattleUnit currentEnemy = enemyUnit;
        if (currentEnemy == null) return;
        StatusEffectHolder holder = currentEnemy.StatusEffects;
        if (holder == null) return;

        holder.ConsumeEffectTurn(StatusEffectType.Corrosion);
    }


    /// <summary>
    /// プレイヤーの駆動遅延。
    /// プレイヤーターン終了時、敵の cooldown を追加で1進める。
    /// 1ターン効果でも次の敵攻撃テンポに確実に影響するよう、
    /// EncounterFlowController の敵ターン開始前に適用する。
    /// </summary>
    private void ApplyPlayerSlowPenaltyOnTurnEnd()
    {
        if (currentEncounter != EncounterType.Enemy) return;
        if (playerUnit == null || playerUnit.StatusEffects == null) return;
        if (!playerUnit.StatusEffects.HasEffect(StatusEffectType.Slow)) return;

        BattleUnit currentEnemy = enemyUnit;
        if (currentEnemy != null && !currentEnemy.IsDead())
        {
            int beforeCooldown = currentEnemy.currentCooldown;
            currentEnemy.TickCooldown();

            if (currentEnemy.currentCooldown < beforeCooldown)
            {
                Vector3 textPos = playerUnit.transform.position + Vector3.up * 1.5f;
                SpawnDamageText("駆動遅延！", textPos, new Color(0.45f, 0.9f, 1f));
            }
        }

        playerUnit.StatusEffects.ConsumeEffectTurn(StatusEffectType.Slow);
    }

    public void TryUseInventoryItem(int slotIndex)
    {
        if (!isPlayerTurn) return;
        if (battleInventoryController == null) return;

        BattleItemData item = battleInventoryController.GetItemAt(slotIndex);
        if (item == null) return;
        if (item.useTarget == BattleItemUseTarget.Enemy) return;

        BattleUnit target = null;
        if (!CanUseBattleItem(item, target))
        {
            return;
        }

        StartCoroutine(UseInventoryItemRoutine(slotIndex, target));
    }

    public void TryUseInventoryItemByDrag(int slotIndex, Vector2 screenPosition)
    {
        if (!isPlayerTurn) return;
        if (battleInventoryController == null) return;

        BattleItemData item = battleInventoryController.GetItemAt(slotIndex);
        if (item == null) return;
        if (item.useTarget != BattleItemUseTarget.Enemy) return;

        if (!TryGetDraggedEnemyTarget(screenPosition, out BattleUnit target))
        {
            return;
        }

        if (!CanUseBattleItem(item, target))
        {
            return;
        }

        StartCoroutine(UseInventoryItemRoutine(slotIndex, target));
    }

    private bool CanUseBattleItem(BattleItemData item, BattleUnit target)
    {
        if (item == null) return false;

        switch (item.itemType)
        {
            case BattleItemType.FieldBandage:
                return playerUnit != null
                    && !playerUnit.IsDead()
                    && playerUnit.CurrentHP < playerUnit.maxHP;

            case BattleItemType.ActivationCell:
                return playerCombatController != null
                    && playerCombatController.GetGunGauge() < playerCombatController.GetGunGaugeMax();

            case BattleItemType.ShockCanister:
                return target != null && !target.IsDead();

            case BattleItemType.MagneticCollectorCanister:
                return true;

            case BattleItemType.AttackOil:
                return playerUnit != null && !playerUnit.IsDead();
        }

        return false;
    }

    public bool CanUseInventoryItemAt(int slotIndex)
    {
        if (!isPlayerTurn) return false;
        if (battleInventoryController == null) return false;

        BattleItemData item = battleInventoryController.GetItemAt(slotIndex);
        if (item == null) return false;

        BattleUnit target = null;

        if (item.useTarget == BattleItemUseTarget.Enemy)
        {
            if (!TryGetValidEnemyTarget(out target))
            {
                return false;
            }
        }

        return CanUseBattleItem(item, target);
    }

    public int GetCurrentScrap()
    {
        return currentScrap;
    }

    private bool TryGetDraggedEnemyTarget(Vector2 screenPosition, out BattleUnit target)
    {
        target = null;

        if (!TryGetValidEnemyTarget(out BattleUnit enemy))
        {
            return false;
        }

        if (!IsScreenPositionNearEnemy(screenPosition, enemy))
        {
            return false;
        }

        target = enemy;
        return true;
    }

    public void SetEnemyDragHoverByScreenPosition(Vector2 screenPosition)
    {
        if (!TryGetValidEnemyTarget(out BattleUnit enemy))
        {
            ClearEnemyDragHoverVisual();
            return;
        }

        bool isHovering = IsScreenPositionNearEnemy(screenPosition, enemy);
        ApplyEnemyDragHoverVisual(enemy, isHovering);
    }

    public void ClearEnemyDragHoverVisual()
    {
        if (!enemyDragHoverActive) return;

        if (enemyDragHoverTarget != null)
        {
            enemyDragHoverTarget.transform.localScale = enemyDragHoverOriginalScale;

            if (enemyPresentationController != null)
            {
                enemyPresentationController.RestoreEnemyColors(enemyDragHoverTarget);
            }
        }

        enemyDragHoverActive = false;
        enemyDragHoverTarget = null;
    }

    private void ApplyEnemyDragHoverVisual(BattleUnit target, bool isHovering)
    {
        if (target == null || !isHovering)
        {
            ClearEnemyDragHoverVisual();
            return;
        }

        if (!enemyDragHoverActive || enemyDragHoverTarget != target)
        {
            ClearEnemyDragHoverVisual();
            enemyDragHoverTarget = target;
            enemyDragHoverOriginalScale = target.transform.localScale;
            enemyDragHoverActive = true;
        }

        target.transform.localScale = enemyDragHoverOriginalScale * Mathf.Max(1f, enemyDragHoverScale);

        SpriteRenderer[] renderers = target.GetComponentsInChildren<SpriteRenderer>(true);
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] == null) continue;

            Color c = renderers[i].color;
            c.r = enemyDragHoverColor.r;
            c.g = enemyDragHoverColor.g;
            c.b = enemyDragHoverColor.b;
            c.a = enemyDragHoverColor.a;
            renderers[i].color = c;
        }
    }

    private bool IsScreenPositionNearEnemy(Vector2 screenPosition, BattleUnit enemy)
    {
        if (enemy == null || enemy.IsDead())
        {
            return false;
        }

        Camera mainCam = Camera.main;
        if (mainCam == null)
        {
            return false;
        }

        Vector3 enemyWorldPos = enemy.transform.position + Vector3.up * 0.75f;
        Renderer enemyRenderer = enemy.GetComponentInChildren<Renderer>();
        if (enemyRenderer != null)
        {
            enemyWorldPos = enemyRenderer.bounds.center;
        }

        Vector2 enemyScreenPos = RectTransformUtility.WorldToScreenPoint(mainCam, enemyWorldPos);
        float radius = Mathf.Max(32f, enemyItemDragDropRadius);

        return Vector2.Distance(screenPosition, enemyScreenPos) <= radius;
    }

    private float GetBattleItemResolveDelay(BattleItemData item)
    {
        if (item == null)
        {
            return itemUseDelay;
        }

        switch (item.itemType)
        {
            case BattleItemType.MagneticCollectorCanister:
                return Mathf.Max(itemUseDelay, 0.45f);
        }

        return itemUseDelay;
    }

    private IEnumerator UseInventoryItemRoutine(int slotIndex, BattleUnit target)
    {
        SetBoardInteractable(false);

        BattleItemData item = battleInventoryController.RemoveAt(slotIndex);
        if (item == null)
        {
            SetBoardInteractable(true);
            yield break;
        }

        ApplyBattleItem(item, target);

        if (battleUIController != null)
        {
            battleUIController.RefreshInventoryUI();
            battleUIController.RefreshGunUI();
        }

        yield return new WaitForSeconds(GetBattleItemResolveDelay(item));
        StartCoroutine(EndPlayerTurn());
    }

    private void ApplyBattleItem(BattleItemData item, BattleUnit target)
    {
        if (item == null) return;

        switch (item.itemType)
        {
            case BattleItemType.FieldBandage:
                if (playerUnit != null)
                {
                    playerUnit.Heal(item.power);
                    Vector3 healPos = playerUnit.transform.position + Vector3.up * 1.5f;
                    SpawnDamageText($"+{item.power}", healPos, Color.green);
                    playerPowerupFeedbackPresenter?.PlayItemUseFeedback(item.itemType);
                }
                break;

            case BattleItemType.ActivationCell:
                if (playerCombatController != null)
                {
                    playerCombatController.AddGunGauge(item.power);
                }

                if (playerUnit != null)
                {
                    Vector3 cellPos = playerUnit.transform.position + Vector3.up * 1.5f;
                    SpawnDamageText($"GUN +{item.power}", cellPos, Color.cyan);
                    playerPowerupFeedbackPresenter?.PlayItemUseFeedback(item.itemType);
                }
                break;

            case BattleItemType.ShockCanister:
                if (target != null && !target.IsDead())
                {
                    battleEventHub?.RaiseEnemyDamageRequested(item.power);
                }
                break;

            case BattleItemType.MagneticCollectorCanister:
                {
                    int gainedCoins = Mathf.Max(1, item.power);
                    AddCoins(gainedCoins);

                    Vector3 coinPos = playerUnit != null
                        ? playerUnit.transform.position + Vector3.up * 1.5f
                        : transform.position + Vector3.up * 1.5f;

                    SpawnDamageText($"+{gainedCoins}G", coinPos, new Color(1f, 0.9f, 0.2f));
                }
                break;

            case BattleItemType.AttackOil:
                ApplyAttackOilBuff(item);
                if (playerUnit != null)
                {
                    Vector3 oilPos = playerUnit.transform.position + Vector3.up * 1.5f;
                    SpawnDamageText($"攻撃UP {playerDamageBoostTurnsRemaining}T", oilPos, new Color(1f, 0.7f, 0.2f));
                    playerPowerupFeedbackPresenter?.PlayItemUseFeedback(item.itemType);
                }
                break;
        }
    }

    private void TryAwardEnemyDrop(BattleUnit defeatedEnemy)
    {
        if (battleInventoryController == null) return;
        if (defeatedEnemy == null) return;
        if (itemDropEntries == null || itemDropEntries.Count == 0) return;
        if (UnityEngine.Random.value > enemyItemDropChance) return;

        BattleItemType itemType = RollDroppedItemType();
        if (itemType == BattleItemType.None) return;

        BattleItemData item = CreateBattleItem(itemType);
        if (item == null) return;

        pendingDropFeedback = new PendingDropFeedback
        {
            hasDrop = false,
            overflow = false,
            slotIndex = -1,
            scrapAmount = 0,
            itemName = item.itemName,
            worldPos = defeatedEnemy.transform.position
        };

        int slotIndexBeforeAdd = battleInventoryController.Count;

        if (battleInventoryController.TryAddItem(item))
        {
            pendingDropFeedback.hasDrop = true;
            pendingDropFeedback.slotIndex = slotIndexBeforeAdd;
        }
        else
        {
            int addedScrap = Mathf.Max(0, scrapOnOverflow);
            currentScrap += addedScrap;

            pendingDropFeedback.hasDrop = true;
            pendingDropFeedback.overflow = true;
            pendingDropFeedback.scrapAmount = addedScrap;
        }
    }

    private IEnumerator PlayPendingDropFeedback()
    {
        if (!pendingDropFeedback.hasDrop) yield break;

        Vector3 effectPos = pendingDropFeedback.worldPos + Vector3.up * 0.9f;
        Vector3 textPos = pendingDropFeedback.worldPos + Vector3.up * 1.8f;

        if (pendingDropFeedback.overflow)
        {
            if (hitEffectPrefab != null)
            {
                SpawnOneShotEffect(hitEffectPrefab, effectPos, 0.25f);
            }

            SpawnDamageText("ITEM LOST", textPos + Vector3.up * 0.35f, new Color(1f, 0.6f, 0.6f));
            SpawnDamageText($"SCRAP +{pendingDropFeedback.scrapAmount}", textPos, Color.gray);

            if (battleUIController != null)
            {
                battleUIController.RefreshInventoryUI();
                battleUIController.PlayItemDropFeedback(-1, true);
            }
        }
        else
        {
            if (absorbEffectPrefab != null)
            {
                SpawnOneShotEffect(absorbEffectPrefab, effectPos, 0.55f);
            }
            else if (hitEffectPrefab != null)
            {
                SpawnOneShotEffect(hitEffectPrefab, effectPos, 0.25f);
            }

            SpawnDamageText("ITEM GET!", textPos + Vector3.up * 0.35f, new Color(1f, 0.9f, 0.25f));
            SpawnDamageText(pendingDropFeedback.itemName, textPos, Color.cyan);

            if (battleUIController != null)
            {
                battleUIController.RefreshInventoryUI();
                battleUIController.PlayItemDropFeedback(pendingDropFeedback.slotIndex, false);
            }
        }

        pendingDropFeedback = default;
        yield return new WaitForSeconds(dropFeedbackHoldDelay);
    }

    public IEnumerator PlayEnemyDefeatSequence(BattleUnit defeatedEnemy, System.Action resolveAfterSequence)
    {
        if (defeatSequenceRunning)
        {
            resolveAfterSequence?.Invoke();
            yield break;
        }

        defeatSequenceRunning = true;

        yield return new WaitForSeconds(defeatSequenceStartDelay);

        // 待たずに流す
        if (pendingDropFeedback.hasDrop)
        {
            StartCoroutine(PlayPendingDropFeedback());
        }

        yield return new WaitForSeconds(defeatSequenceBeforeRewardDelay);

        resolveAfterSequence?.Invoke();

        yield return new WaitForSeconds(defeatSequenceAfterRewardDelay);

        if (battleUIController != null)
        {
            battleUIController.RefreshGunUI();
            battleUIController.RefreshInventoryUI();
        }

        defeatSequenceRunning = false;
    }

    private BattleItemType RollDroppedItemType()
    {
        if (itemDropEntries == null || itemDropEntries.Count == 0)
        {
            return BattleItemType.None;
        }

        int totalWeight = 0;
        for (int i = 0; i < itemDropEntries.Count; i++)
        {
            BattleItemDropEntry entry = itemDropEntries[i];
            if (entry == null) continue;
            if (entry.itemType == BattleItemType.None) continue;
            totalWeight += Mathf.Max(0, entry.weight);
        }

        if (totalWeight <= 0)
        {
            return BattleItemType.None;
        }

        int roll = UnityEngine.Random.Range(0, totalWeight);
        int cumulative = 0;

        for (int i = 0; i < itemDropEntries.Count; i++)
        {
            BattleItemDropEntry entry = itemDropEntries[i];
            if (entry == null) continue;
            if (entry.itemType == BattleItemType.None) continue;

            cumulative += Mathf.Max(0, entry.weight);
            if (roll < cumulative)
            {
                return entry.itemType;
            }
        }

        return BattleItemType.None;
    }


    // PanelBattleManager に追加
    public void UpdateFloorUI()
    {
        if (stageFlowController == null) return;

        int totalFloors = Mathf.Max(1, stageFlowController.TotalBattles);
        int currentFloor = GetDisplayFloorNumber();

        if (battleUIController != null)
        {
            battleUIController.SetFloorText(currentFloor, totalFloors);
        }

        ApplyCurrentBackgroundTheme(currentFloor);
    }

    private int GetDisplayFloorNumber()
    {
        if (stageFlowController == null)
        {
            return 1;
        }

        int totalFloors = Mathf.Max(1, stageFlowController.TotalBattles);
        bool hasLivingEnemy = enemyUnit != null && !enemyUnit.IsDead();

        int floor = hasLivingEnemy
            ? stageFlowController.DefeatedEnemyCount + 1
            : Mathf.Max(1, stageFlowController.DefeatedEnemyCount);

        return Mathf.Clamp(floor, 1, totalFloors);
    }

    private void ApplyCurrentBackgroundTheme(int currentFloor)
    {
        if (battleBackgroundThemeController == null)
        {
            return;
        }

        battleBackgroundThemeController.ApplyTheme(currentFloor);
    }

    private bool ShouldPlayThemeChangeFadeOnTravel(out int targetFloor)
    {
        targetFloor = 1;

        if (!enableThemeChangeFadeTransition || stageFlowController == null || battleBackgroundThemeController == null)
        {
            return false;
        }

        int totalFloors = Mathf.Max(1, stageFlowController.TotalBattles);
        int defeatedCount = Mathf.Max(0, stageFlowController.DefeatedEnemyCount);

        bool enteringEnemyEncounter = currentEncounter == EncounterType.Enemy;
        int rawTargetFloor = enteringEnemyEncounter
            ? defeatedCount + 1
            : Mathf.Max(1, defeatedCount);

        targetFloor = Mathf.Clamp(rawTargetFloor, 1, totalFloors);
        return battleBackgroundThemeController.WouldThemeChange(targetFloor);
    }

    private bool TryGetValidEnemyTarget(out BattleUnit target)
    {
        target = enemyUnit;
        if (target == null) return false;
        if (target.IsDead()) return false;
        return true;
    }


    private PlayerAnimationPresenter GetPlayerAnimationPresenter()
    {
        if (playerUnit == null) return null;
        return playerUnit.GetComponent<PlayerAnimationPresenter>();
    }


    public BattleUnit enemyUnit
    {
        get => battleContext != null ? battleContext.CurrentEnemy : null;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.CurrentEnemy = value;
            }

            if (value != null && !value.IsDead())
            {
                UpdateFloorUI();
            }
        }
    }

    public EncounterType currentEncounter
    {
        get => battleContext != null ? battleContext.CurrentEncounter : EncounterType.Enemy;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.CurrentEncounter = value;
            }
        }
    }

    public int remainingSteps
    {
        get => battleContext != null ? battleContext.RemainingSteps : 0;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.RemainingSteps = value;
            }
        }
    }

    private int currentCoins
    {
        get => battleContext != null ? battleContext.CurrentCoins : 0;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.CurrentCoins = value;
            }
        }
    }

    private bool isPlayerTurn
    {
        get => battleContext != null && battleContext.IsPlayerTurn;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.IsPlayerTurn = value;
            }
        }
    }

    private bool isEnemySpawning
    {
        get => battleContext != null && battleContext.IsEnemySpawning;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.IsEnemySpawning = value;
            }
        }
    }

    private bool isEnemyDefeatedThisTurn
    {
        get => battleContext != null && battleContext.IsEnemyDefeatedThisTurn;
        set
        {
            EnsureBattleContext();
            if (battleContext != null)
            {
                battleContext.IsEnemyDefeatedThisTurn = value;
            }
        }
    }

    [Header("ダンジョン演出")]
    public Transform dungeonMistRoot;
    [Range(0f, 1f)] public float battleMistAlpha = 0.8f;
    public float mistFadeDuration = 0.35f;

    [Header("移動演出")]
    public float roomTravelDuration = 0.58f;
    public Ease roomTravelEase = Ease.OutCubic;
    public float enemyRevealDuration = 0.2f;


    [Header("バトル演出")]
    public GameObject damageTextPrefab;
    public GameObject hitEffectPrefab;
    public GameObject pistolMuzzleFlashPrefab;
    public GameObject energyOrbPrefab;
    public GameObject absorbEffectPrefab;
    public GameObject levelUpEffectPrefab;

    [Header("パネルエネルギー色")]
    [SerializeField] private Color swordEnergyColor = new Color(0.52f, 0.92f, 1f, 1f);
    [SerializeField] private Color ammoEnergyColor = new Color(0.92f, 0.95f, 1f, 1f);
    [SerializeField] private Color coinEnergyColor = new Color(1f, 0.86f, 0.22f, 1f);
    [SerializeField] private Color healEnergyColor = new Color(0.52f, 1f, 0.52f, 1f);
    [SerializeField] private Color levelUpEnergyColor = new Color(0.76f, 0.42f, 1f, 1f);

    [Header("コイン報酬設定")]
    [SerializeField, Min(0)] private int battleCoinBonusMid = 1;
    [SerializeField, Min(1)] private int battleCoinBonusMidStart = 8;
    [SerializeField, Min(0)] private int battleCoinBonusLate = 2;
    [SerializeField, Min(1)] private int battleCoinBonusLateStart = 16;
    [SerializeField, Min(0)] private int battleCoinBonusEnd = 3;
    [SerializeField, Min(1)] private int battleCoinBonusEndStart = 24;
    [SerializeField] private bool disableCoinPanels = true;

    [Header("ステージ進行設定")]
    public Transform battlePosition;
    public Vector3 waitOffset = new Vector3(2.5f, 0, 0);
    public int maxFloors = 100;
    public int maxVisibleEnemies = 3;
    public List<BattleUnit> enemyPrefabs;
    public StageConfig stageConfig;

    private CanvasGroup boardCanvasGroup;
    private EffectPoolManager effectPoolManager;

    private const int rows = 6;
    private const int cols = 6;

    public int BoardRows => rows;
    public int BoardCols => cols;
    public bool IsEnemySpawning => isEnemySpawning;
    public bool IsEnemyDefeatedThisTurn => isEnemyDefeatedThisTurn;

    private bool isEventHubSubscribed;

    // ============================================
    // 弾薬パネルのゲージ供給量
    // ============================================
    [Header("弾薬パネル設定")]
    [Tooltip("弾薬パネル1個あたりのゲージ供給量（主食）")]
    [SerializeField] private int ammoGaugePerPanel = 2;

    [Tooltip("攻撃パネル消去時のゲージ供給量（おやつ）")]
    [SerializeField] private int swordGaugeBonusPerAction = 1;

    private void SubscribeBattleEvents()
    {
        if (battleEventHub == null || isEventHubSubscribed)
        {
            return;
        }

        battleEventHub.BoardInteractableRequested += HandleBoardInteractableRequested;
        battleEventHub.CoinsGained += HandleCoinsGained;
        battleEventHub.EnergyOrbRequested += HandleEnergyOrbRequested;
        battleEventHub.AmmoCollected += HandleAmmoCollected;
        battleEventHub.SwordBonusGaugeRequested += HandleSwordBonusGauge;
        battleEventHub.EncounterStateChanged += HandleEncounterStateChanged;
        battleEventHub.DungeonMistRequested += HandleDungeonMistRequested;
        battleEventHub.DamageTextRequested += HandleDamageTextRequested;
        battleEventHub.OneShotEffectRequested += HandleOneShotEffectRequested;
        battleEventHub.ExpTextRequested += HandleExpTextRequested;
        battleEventHub.LevelUpTextRequested += HandleLevelUpTextRequested;
        battleEventHub.StageClearRequested += HandleStageClearRequested;
        battleEventHub.PlayerDefeatedRequested += HandlePlayerDefeatedRequested;
        battleEventHub.EnemyDefeated += HandleEnemyDefeatedForDrops;

        isEventHubSubscribed = true;
    }

    private void UnsubscribeBattleEvents()
    {
        if (battleEventHub == null || !isEventHubSubscribed)
        {
            return;
        }

        battleEventHub.BoardInteractableRequested -= HandleBoardInteractableRequested;
        battleEventHub.CoinsGained -= HandleCoinsGained;
        battleEventHub.EnergyOrbRequested -= HandleEnergyOrbRequested;
        battleEventHub.AmmoCollected -= HandleAmmoCollected;
        battleEventHub.SwordBonusGaugeRequested -= HandleSwordBonusGauge;
        battleEventHub.EncounterStateChanged -= HandleEncounterStateChanged;
        battleEventHub.DungeonMistRequested -= HandleDungeonMistRequested;
        battleEventHub.DamageTextRequested -= HandleDamageTextRequested;
        battleEventHub.OneShotEffectRequested -= HandleOneShotEffectRequested;
        battleEventHub.ExpTextRequested -= HandleExpTextRequested;
        battleEventHub.LevelUpTextRequested -= HandleLevelUpTextRequested;
        battleEventHub.StageClearRequested -= HandleStageClearRequested;
        battleEventHub.PlayerDefeatedRequested -= HandlePlayerDefeatedRequested;
        battleEventHub.EnemyDefeated -= HandleEnemyDefeatedForDrops;

        isEventHubSubscribed = false;
    }

    private void HandleBoardInteractableRequested(bool isInteractable)
    {
        SetBoardInteractable(isInteractable);
    }

    private void HandleCoinsGained(int amount)
    {
        AddCoins(amount);
    }

    private void HandleEnergyOrbRequested(PanelType panelType, Vector3 startPos, Vector3 target, float duration, float delay)
    {
        SpawnEnergyOrb(panelType, startPos, target, duration, delay);
    }

    // ============================================
    // 弾薬パネル収集 → 銃ゲージ加算（主食: +2/枚）
    // ============================================
    private void HandleAmmoCollected(int panelCount)
    {
        if (playerCombatController == null) return;
        if (panelCount <= 0) return;

        int gaugeGain = panelCount * ammoGaugePerPanel;
        playerCombatController.AddGunGauge(gaugeGain);

        if (battleUIController != null)
        {
            battleUIController.RefreshGunUI();
        }
    }

    // ============================================
    // 攻撃パネル消去 → 銃ゲージ微量加算（おやつ: +1/回）
    // ============================================
    private void HandleSwordBonusGauge()
    {
        if (playerCombatController == null) return;

        playerCombatController.AddGunGauge(swordGaugeBonusPerAction);

        if (battleUIController != null)
        {
            battleUIController.RefreshGunUI();
        }
    }

    private void HandleEncounterStateChanged(EncounterType encounterType, int steps)
    {
        SetEncounterState(encounterType, steps);
    }

    private void HandleDungeonMistRequested(bool isBattle, bool immediate)
    {
        SetDungeonMist(isBattle, immediate);
    }

    private void HandleDamageTextRequested(string text, Vector3 position, Color color)
    {
        SpawnDamageText(text, position, color);
    }

    private void HandleOneShotEffectRequested(GameObject prefab, Vector3 position, float returnDelay)
    {
        SpawnOneShotEffect(prefab, position, returnDelay);
    }

    private void HandleExpTextRequested(int exp, Vector3 position, float delay)
    {
        StartCoroutine(SpawnExpTextWithDelay(exp, position, delay));
    }

    private void HandleLevelUpTextRequested(float delay)
    {
        StartCoroutine(SpawnLevelUpTextWithDelay(delay));
    }

    private void HandleStageClearRequested()
    {
        OnStageClear();
    }

    private void HandlePlayerDefeatedRequested()
    {
        OnPlayerDefeated();
    }

    private void HandleEnemyDefeatedForDrops(BattleUnit defeatedEnemy)
    {
        TryAwardEnemyDrop(defeatedEnemy);
    }

    private void EnsureBattleContext()
    {
        if (battleContext == null)
        {
            battleContext = GetComponent<BattleContext>();
        }

        if (battleContext == null)
        {
            battleContext = gameObject.AddComponent<BattleContext>();
        }
    }

    private void EnsurePlayerPowerupFeedbackPresenter()
    {
        if (playerPowerupFeedbackPresenter != null)
        {
            return;
        }

        if (playerUnit != null)
        {
            playerPowerupFeedbackPresenter = playerUnit.GetComponent<PlayerPowerupFeedbackPresenter>();
            if (playerPowerupFeedbackPresenter == null)
            {
                playerPowerupFeedbackPresenter = playerUnit.gameObject.AddComponent<PlayerPowerupFeedbackPresenter>();
            }
        }
    }

    private void SubscribePlayerPowerupFeedbackEvents()
    {
        if (powerupFeedbackEventsSubscribed)
        {
            return;
        }

        if (playerCombatController == null)
        {
            return;
        }

        playerCombatController.OnMeleeWeaponEquipped += HandleWeaponEquippedFeedback;
        playerCombatController.OnGunEquipped += HandleGunEquippedFeedback;
        powerupFeedbackEventsSubscribed = true;
    }

    private void UnsubscribePlayerPowerupFeedbackEvents()
    {
        if (!powerupFeedbackEventsSubscribed || playerCombatController == null)
        {
            return;
        }

        playerCombatController.OnMeleeWeaponEquipped -= HandleWeaponEquippedFeedback;
        playerCombatController.OnGunEquipped -= HandleGunEquippedFeedback;
        powerupFeedbackEventsSubscribed = false;
    }

    private void HandleWeaponEquippedFeedback(WeaponType weaponType)
    {
        playerPowerupFeedbackPresenter?.PlayWeaponEquipFeedback(weaponType);
    }

    private void HandleGunEquippedFeedback(GunType gunType)
    {
        playerPowerupFeedbackPresenter?.PlayGunEquipFeedback(gunType);
    }

    void Awake()
    {
        EnsureBattleContext();
        EnsureInventoryController();
        EnsureDefaultItemDrops();

        if (battleBootstrapper == null)
        {
            battleBootstrapper = GetComponent<BattleBootstrapper>();
        }

        if (battleBootstrapper == null)
        {
            battleBootstrapper = gameObject.AddComponent<BattleBootstrapper>();
        }

        battleBootstrapper.EnsureDependencies(this);
        EnsurePlayerPowerupFeedbackPresenter();
        SubscribePlayerPowerupFeedbackEvents();
        SubscribeBattleEvents();
    }

    void Start()
    {
        DOTween.Init();

        if (battleBootstrapper == null)
        {
            Debug.LogError("BattleBootstrapper が取得できません。");
            enabled = false;
            return;
        }

        bool initialized = battleBootstrapper.Initialize(this);
        if (!initialized)
        {
            enabled = false;
            return;
        }

        InitializeShop();
        InitializeRewardDrops();

        if (battleUIController != null)
        {
            battleUIController.RefreshInventoryUI();
            battleUIController.RefreshGunUI();
        }

        UpdateFloorUI();
        RefreshPlayerExpUI();

        EnsurePlayerPowerupFeedbackPresenter();
        SubscribePlayerPowerupFeedbackEvents();

        if (ShouldPlayGameStartIntro && currentEncounter == EncounterType.Enemy)
        {
            stageIntroController.BeginGameStartIntro(this);
        }
        else
        {
            SetDungeonMist(true, true);
            SetBoardInteractable(true);
        }
    }

    private void OnDestroy()
    {
        UnsubscribePlayerPowerupFeedbackEvents();
        UnsubscribeBattleEvents();
    }

    // ============================================
    // 商店の初期化
    // ============================================
    private void InitializeShop()
    {
        if (shopController == null) return;

        shopController.Initialize(
            playerCombatController,
            battleInventoryController,
            playerUnit,
            battleUIController,
            battleItemIconDatabase,
            () => currentCoins,
            (amount) => AddCoins(amount));

        shopController.SetStageFlowController(stageFlowController);

        // EncounterFlowController に商店コントローラーを渡す
        if (encounterFlowController != null)
        {
            encounterFlowController.SetShopController(shopController);
        }
    }


    private void InitializeRewardDrops()
    {
        if (rewardDropController == null)
        {
            rewardDropController = GetComponent<RewardDropController>();
        }

        if (rewardDropController == null)
        {
            rewardDropController = gameObject.AddComponent<RewardDropController>();
        }

        rewardDropController.Initialize(playerCombatController, battleUIController, panelBoardController, battleEventHub);
        battleDamageResolver?.SetRewardDropController(rewardDropController, GetCurrentRewardBattleNumber);

        if (encounterFlowController != null)
        {
            encounterFlowController.SetRewardDropController(rewardDropController);
        }
    }

    public int GetCurrentCoins()
    {
        return currentCoins;
    }

    public void SetEffectPoolManager(EffectPoolManager poolManager)
    {
        effectPoolManager = poolManager;
    }

    public EffectPoolManager GetEffectPoolManager()
    {
        return effectPoolManager;
    }

    public void SetBoardCanvasGroup(CanvasGroup canvasGroup)
    {
        boardCanvasGroup = canvasGroup;
    }

    public void SetEnemySpawning(bool value)
    {
        isEnemySpawning = value;
    }

    public void SetEnemyDefeatedThisTurn(bool value)
    {
        isEnemyDefeatedThisTurn = value;
    }

    public IEnumerator PlayEnemyEntranceRoutine(BattleUnit unit)
    {
        if (unit == null)
        {
            yield break;
        }

        if (BossIntroController.IsBossUnit(unit) && bossIntroController != null)
        {
            enemyPresentationController?.PrepareEnemyForDeferredEntrance(unit);
            unit.InitializeTurn();
            yield return StartCoroutine(bossIntroController.PlayBossIntro(unit));

            if (unit.animator != null)
            {
                unit.animator.Play("IDLE", 0, 0f);
            }

            yield break;
        }

        enemyPresentationController?.ActivateEnemyAsCurrent(unit);
    }

    public void SetEncounterState(EncounterType encounterType, int steps)
    {
        currentEncounter = encounterType;
        remainingSteps = steps;

        if (encounterType != EncounterType.Enemy)
        {
            panelBoardController?.ClearAllAttachedItems();
        }

        UpdateEncounterUI();
    }

    public void UpdateEncounterUI()
    {
        if (battleUIController != null)
        {
            battleUIController.SetEncounterInfo(currentEncounter, remainingSteps);
        }
    }

    public void SetDungeonMist(bool isBattle, bool immediate = false)
    {
        if (dungeonMistController != null)
        {
            dungeonMistController.ApplyBattleState(isBattle, immediate);
        }
    }

    public int GetCurrentRewardBattleNumber()
    {
        if (stageFlowController == null)
        {
            return 1;
        }

        int total = stageFlowController.TotalBattles > 0 ? stageFlowController.TotalBattles : maxFloors;
        bool hasLivingEnemy = enemyUnit != null && !enemyUnit.IsDead();

        int battleNumber = hasLivingEnemy
            ? stageFlowController.DefeatedEnemyCount + 1
            : Mathf.Max(1, stageFlowController.DefeatedEnemyCount);

        return Mathf.Clamp(battleNumber, 1, Mathf.Max(1, total));
    }

    public int GetBattleCoinBonusForCurrentEncounter()
    {
        return GetBattleCoinBonusForBattle(GetCurrentRewardBattleNumber());
    }

    public int GetBattleCoinBonusForBattle(int battleNumber)
    {
        if (battleNumber >= battleCoinBonusEndStart)
        {
            return battleCoinBonusEnd;
        }

        if (battleNumber >= battleCoinBonusLateStart)
        {
            return battleCoinBonusLate;
        }

        if (battleNumber >= battleCoinBonusMidStart)
        {
            return battleCoinBonusMid;
        }

        return 0;
    }

    public int CalculateEnemyCoinReward(BattleUnit defeatedEnemy)
    {
        if (defeatedEnemy == null)
        {
            return 0;
        }

        int baseCoins = Mathf.Max(0, defeatedEnemy.coinYield);
        int stageBonus = GetBattleCoinBonusForCurrentEncounter();
        return Mathf.Max(0, baseCoins + stageBonus);
    }

    public void UpdateCoinUI()
    {
        if (battleUIController != null)
        {
            battleUIController.SetCoinText(currentCoins);
        }
    }

    public void AddCoins(int amount)
    {
        currentCoins += amount;
        currentCoins = Mathf.Max(0, currentCoins);
        UpdateCoinUI();

        if (amount > 0 && battleUIController != null)
        {
            battleUIController.PlayCoinReceivePulse();
        }
    }

    public IEnumerator EndPlayerTurn()
    {
        if (encounterFlowController == null)
        {
            yield break;
        }

        TickPlayerTimedBuffsOnTurnEnd();
        ApplyPlayerSlowPenaltyOnTurnEnd();
        TickEnemyPassiveEffectsOnPlayerTurnEnd();
        if (battleUIController != null)
        {
            battleUIController.RefreshInventoryUI();
        }

        yield return StartCoroutine(encounterFlowController.EndPlayerTurnRoutine());
    }

    public void AdvanceEmptyTurn()
    {
        if (encounterFlowController == null)
        {
            return;
        }

        encounterFlowController.AdvanceEmptyTurn();
    }

    public IEnumerator TravelForward()
    {
        PlayerAnimationPresenter playerAnim = GetPlayerAnimationPresenter();
        if (playerAnim != null)
        {
            playerAnim.PlayRun();
        }

        int targetFloor;
        if (ShouldPlayThemeChangeFadeOnTravel(out targetFloor))
        {
            yield return StartCoroutine(TravelForwardWithThemeChangeFade(playerAnim, targetFloor));
            yield break;
        }

        if (roomTravelController != null)
        {
            yield return roomTravelController.TravelForward(playerUnit.transform, waitOffset);

            if (playerAnim != null)
            {
                playerAnim.PlayIdle();
            }

            yield break;
        }

        if (playerUnit == null)
        {
            yield break;
        }

        playerUnit.transform
            .DOMove(playerUnit.transform.position + waitOffset, roomTravelDuration)
            .SetEase(roomTravelEase);

        Camera mainCam = Camera.main;
        if (mainCam != null)
        {
            mainCam.transform
                .DOMove(mainCam.transform.position + waitOffset, roomTravelDuration)
                .SetEase(roomTravelEase);
        }

        yield return new WaitForSeconds(roomTravelDuration);

        if (playerAnim != null)
        {
            playerAnim.PlayIdle();
        }
    }

    private IEnumerator TravelForwardWithThemeChangeFade(PlayerAnimationPresenter playerAnim, int targetFloor)
    {
        if (playerUnit == null)
        {
            ApplyCurrentBackgroundTheme(targetFloor);
            yield break;
        }

        EnsureThemeChangeFadeOverlay();

        playerUnit.transform.DOKill(false);

        Camera mainCam = Camera.main;
        if (mainCam != null)
        {
            mainCam.transform.DOKill(false);
        }

        Vector3 playerStartPos = playerUnit.transform.position;
        Vector3 cameraStartPos = mainCam != null ? mainCam.transform.position : Vector3.zero;

        Vector3 exitTargetPos = ResolvePlayerHorizontalExitPosition(mainCam, themeChangeExitViewportX, playerStartPos);
        Tween exitTween = playerUnit.transform
            .DOMove(exitTargetPos, Mathf.Max(0.01f, themeChangePlayerExitDuration))
            .SetEase(Ease.InCubic);

        yield return exitTween.WaitForCompletion();

        yield return StartCoroutine(FadeThemeChangeOverlayTo(1f, themeChangeFadeOutDuration));

        if (mainCam != null)
        {
            mainCam.transform.position = cameraStartPos + waitOffset;
        }

        ApplyCurrentBackgroundTheme(targetFloor);

        Vector3 playerTargetPos = playerStartPos + waitOffset;
        Vector3 playerEntryPos = ResolvePlayerHorizontalExitPosition(mainCam, themeChangeEntryViewportX, playerTargetPos);
        playerUnit.transform.position = playerEntryPos;

        if (themeChangeFadeHoldDuration > 0f)
        {
            yield return new WaitForSeconds(themeChangeFadeHoldDuration);
        }

        if (playerAnim != null)
        {
            playerAnim.PlayRun();
        }

        Tween entryTween = playerUnit.transform
            .DOMove(playerTargetPos, Mathf.Max(0.01f, themeChangePlayerEntryDuration))
            .SetEase(Ease.OutCubic);

        yield return StartCoroutine(FadeThemeChangeOverlayTo(0f, themeChangeFadeInDuration));

        if (entryTween != null)
        {
            yield return entryTween.WaitForCompletion();
        }

        if (playerAnim != null)
        {
            playerAnim.PlayIdle();
        }
    }

    private Vector3 ResolvePlayerHorizontalExitPosition(Camera cam, float viewportX, Vector3 currentWorldPosition)
    {
        Vector3 viewportPoint = cam != null ? cam.WorldToViewportPoint(currentWorldPosition) : Vector3.zero;
        float preservedViewportY = cam != null ? Mathf.Clamp01(viewportPoint.y) : 0.5f;
        return ResolvePlayerViewportPosition(cam, viewportX, preservedViewportY, currentWorldPosition);
    }

    private Vector3 ResolvePlayerViewportPosition(Camera cam, float viewportX, float viewportY, Vector3 fallbackWorldPosition)
    {
        if (cam == null)
        {
            float direction = viewportX >= 0.5f ? 1f : -1f;
            float distance = Mathf.Max(Mathf.Abs(waitOffset.x), 3.5f);
            return fallbackWorldPosition + Vector3.right * distance * direction;
        }

        if (cam.orthographic)
        {
            Vector3 worldPoint = cam.ViewportToWorldPoint(new Vector3(
                viewportX,
                viewportY,
                Mathf.Abs(fallbackWorldPosition.z - cam.transform.position.z)));

            worldPoint.z = fallbackWorldPosition.z;
            return worldPoint;
        }

        Plane playerPlane = new Plane(Vector3.forward, new Vector3(0f, 0f, fallbackWorldPosition.z));
        Ray ray = cam.ViewportPointToRay(new Vector3(viewportX, viewportY, 0f));

        if (playerPlane.Raycast(ray, out float distanceToPlane))
        {
            return ray.GetPoint(distanceToPlane);
        }

        float fallbackDirection = viewportX >= 0.5f ? 1f : -1f;
        float fallbackDistance = Mathf.Max(Mathf.Abs(waitOffset.x), 3.5f);
        return fallbackWorldPosition + Vector3.right * fallbackDistance * fallbackDirection;
    }

    private IEnumerator FadeThemeChangeOverlayTo(float targetAlpha, float duration)
    {
        EnsureThemeChangeFadeOverlay();

        if (themeChangeFadeOverlay == null)
        {
            yield break;
        }

        Color color = themeChangeFadeOverlay.color;
        float startAlpha = color.a;

        if (duration <= 0f)
        {
            color.a = targetAlpha;
            themeChangeFadeOverlay.color = color;
            yield break;
        }

        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            color.a = Mathf.Lerp(startAlpha, targetAlpha, t);
            themeChangeFadeOverlay.color = color;
            yield return null;
        }

        color.a = targetAlpha;
        themeChangeFadeOverlay.color = color;
    }

    public void SpawnEnergyOrb(PanelType panelType, Vector3 startPos, Vector3 target, float duration, float delay)
    {
        if (battleEffectController == null) return;

        battleEffectController.SpawnEnergyOrb(
            energyOrbPrefab,
            absorbEffectPrefab,
            startPos,
            target,
            duration,
            delay,
            ResolvePanelEnergyColor(panelType));
    }

    private Color ResolvePanelEnergyColor(PanelType panelType)
    {
        switch (panelType)
        {
            case PanelType.Sword:
                return swordEnergyColor;
            case PanelType.Ammo:
                return ammoEnergyColor;
            case PanelType.Coin:
                return coinEnergyColor;
            case PanelType.Heal:
                return healEnergyColor;
            case PanelType.LvUp:
                return levelUpEnergyColor;
            case PanelType.Corrupt:
                return new Color(0.38f, 0.82f, 0.52f, 1f);
            default:
                return Color.white;
        }
    }

    public IEnumerator SpawnExpTextWithDelay(int exp, Vector3 spawnPos, float delay)
    {
        if (battleEffectController == null)
        {
            yield return new WaitForSeconds(delay);
            yield break;
        }

        yield return battleEffectController.SpawnExpTextWithDelay(damageTextPrefab, exp, spawnPos, delay);
    }

    public IEnumerator SpawnLevelUpTextWithDelay(float delay)
    {
        if (battleEffectController == null || playerUnit == null)
        {
            yield return new WaitForSeconds(delay);
            yield break;
        }

        yield return battleEffectController.SpawnLevelUpTextWithDelay(damageTextPrefab, playerUnit.transform, delay);
    }

    public void SpawnDamageText(string text, Vector3 position, Color color)
    {
        if (battleEffectController == null) return;
        battleEffectController.SpawnDamageText(damageTextPrefab, text, position, color);
    }

    public void SpawnOneShotEffect(GameObject prefab, Vector3 position, float returnDelay)
    {
        if (battleEffectController == null || prefab == null) return;
        battleEffectController.SpawnOneShotEffect(prefab, position, Quaternion.identity, returnDelay);
    }

    public void SpawnOneShotEffect(GameObject prefab, Vector3 position, Quaternion rotation, float returnDelay)
    {
        if (battleEffectController == null || prefab == null) return;
        battleEffectController.SpawnOneShotEffect(prefab, position, rotation, returnDelay);
    }


    public void SpawnOneShotEffect(GameObject prefab, Vector3 position, Quaternion rotation, float returnDelay, Vector3 scale)
    {
        if (battleEffectController == null || prefab == null) return;
        battleEffectController.SpawnOneShotEffect(prefab, position, rotation, returnDelay, scale);
    }

    public void SpawnNextEnemy()
    {
        if (stageFlowController == null) return;
        if (enemyUnit == null) return;

        stageFlowController.SpawnNextEnemyAfter(enemyUnit.transform.position);

        if (enemyPresentationController != null)
        {
            enemyPresentationController.RefreshUpcomingEnemyStandbyVisuals(stageFlowController.GetUpcomingEnemies());
        }

        UpdateFloorUI();
        PrepareItemPanelForCurrentBattle();
    }

    public void SetBoardInteractable(bool isInteractable)
    {
        // === 状態異常: プレイヤー金縛りチェック ===
        // 戦闘中にプレイヤーターンが始まろうとしたとき、
        // 金縛り中なら盤面を開放せずターンをスキップする。
        if (isInteractable
            && !paralysisSkipRunning
            && currentEncounter == EncounterType.Enemy
            && playerUnit != null
            && playerUnit.StatusEffects != null
            && playerUnit.StatusEffects.HasEffect(StatusEffectType.Paralysis))
        {
            StartCoroutine(HandlePlayerParalysisSkip());
            return;
        }

        isPlayerTurn = isInteractable;

        if (boardCanvasGroup != null)
        {
            boardCanvasGroup.interactable = isInteractable;
            boardCanvasGroup.blocksRaycasts = isInteractable;
            boardCanvasGroup.DOFade(isInteractable ? 1.0f : 0.6f, 0.3f);
        }
    }

    /// <summary>
    /// プレイヤー金縛り時のターンスキップ処理。
    /// 盤面を開放せず、スキップ演出後に EndPlayerTurn() を呼ぶ。
    /// EndPlayerTurn() → 敵ターン → SetBoardInteractable(true) と巡回し、
    /// まだ金縛りが残っていれば再びここに来る。
    /// paralysisSkipRunning フラグで多重起動を防止する。
    /// </summary>
    private System.Collections.IEnumerator HandlePlayerParalysisSkip()
    {
        if (paralysisSkipRunning)
        {
            yield break;
        }

        paralysisSkipRunning = true;

        // 盤面ロック状態を維持
        isPlayerTurn = false;

        if (boardCanvasGroup != null)
        {
            boardCanvasGroup.interactable = false;
            boardCanvasGroup.blocksRaycasts = false;
        }

        // 演出テキスト
        Vector3 textPos = playerUnit != null
            ? playerUnit.transform.position + Vector3.up * 1.5f
            : Vector3.up * 1.5f;
        SpawnDamageText("金縛り！", textPos, new Color(0.8f, 0.4f, 1f));

        yield return new WaitForSeconds(paralysisSkipDelay);

        // 行動スキップ後に残りターンを消費
        if (playerUnit != null && playerUnit.StatusEffects != null)
        {
            playerUnit.StatusEffects.ConsumeEffectTurn(StatusEffectType.Paralysis);
        }

        paralysisSkipRunning = false;

        // 通常のターン終了処理へ（敵ターンに遷移する）
        yield return StartCoroutine(EndPlayerTurn());
    }


    public void OnStageClear()
    {
        Debug.Log("ステージクリア！");
        SetBoardInteractable(false);

        if (!returnToHomeOnStageClear || resultReturnSequenceRunning)
        {
            return;
        }

        bool shouldGoEnding =
            useEndingSceneOnFinalClear &&
            stageFlowController != null &&
            stageFlowController.HasConfiguredFinalBattleBeenCleared();

        // エンディング行き かつ エピローグがあるなら、エピローグルートへ
        if (shouldGoEnding && epilogueController != null && epilogueController.HasEpilogue())
        {
            StartCoroutine(EpilogueToEndingRoutine());
            return;
        }

        string destinationSceneName = shouldGoEnding ? endingSceneName : homeSceneName;
        StartCoroutine(ReturnToSceneWithResultRoutine("探索完了", stageClearResultTextColor, destinationSceneName));
    }

    private IEnumerator EpilogueToEndingRoutine()
    {
        resultReturnSequenceRunning = true;

        // 「探索完了」テキスト表示（既存と同じ）
        EnsureResultOverlayUI();

        if (resultMessageText != null)
        {
            Color c = stageClearResultTextColor;
            c.a = 1f;
            resultMessageText.text = "探索完了";
            resultMessageText.color = c;
            resultMessageText.gameObject.SetActive(true);
        }

        if (resultMessageCanvasGroup != null)
        {
            resultMessageCanvasGroup.alpha = 0f;
        }

        // テキストフェードイン
        float elapsed = 0f;
        while (elapsed < resultTextFadeDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / Mathf.Max(0.01f, resultTextFadeDuration));
            if (resultMessageCanvasGroup != null)
                resultMessageCanvasGroup.alpha = t;
            yield return null;
        }

        yield return new WaitForSeconds(resultMessageHoldDuration);

        // テキストフェードアウト
        if (resultMessageCanvasGroup != null)
        {
            elapsed = 0f;
            while (elapsed < resultFadeDuration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / Mathf.Max(0.01f, resultFadeDuration));
                resultMessageCanvasGroup.alpha = 1f - t;
                yield return null;
            }
            resultMessageCanvasGroup.alpha = 0f;
        }

        // ★ エピローグ再生
        yield return StartCoroutine(epilogueController.PlayEpilogue());

        // エンディングへ遷移
        resultReturnSequenceRunning = false;
        SceneTransitionManager.TransitionToScene(endingSceneName, TransitionType.CircleIris);
    }

    public void OnPlayerDefeated()
    {
        Debug.Log("ゲームオーバー");
        SetBoardInteractable(false);

        if (returnToHomeOnGameOver && !resultReturnSequenceRunning)
        {
            StartCoroutine(ReturnToSceneWithResultRoutine("GAME OVER", gameOverResultTextColor, homeSceneName));
        }
    }


    private IEnumerator ReturnToSceneWithResultRoutine(string message, Color messageColor, string destinationSceneName)
    {
        if (resultReturnSequenceRunning)
        {
            yield break;
        }

        resultReturnSequenceRunning = true;
        SetBoardInteractable(false);
        EnsureResultOverlayUI();

        if (resultMessageText != null)
        {
            Color c = messageColor;
            c.a = 1f;
            resultMessageText.text = message;
            resultMessageText.color = c;
            resultMessageText.gameObject.SetActive(true);
        }

        if (resultMessageCanvasGroup != null)
        {
            resultMessageCanvasGroup.alpha = 0f;
            resultMessageCanvasGroup.interactable = false;
            resultMessageCanvasGroup.blocksRaycasts = false;
        }

        if (resultFadeOverlay != null)
        {
            Color fadeColor = resultFadeOverlay.color;
            fadeColor.a = 0f;
            resultFadeOverlay.color = fadeColor;
            resultFadeOverlay.raycastTarget = true;
        }

        float elapsed = 0f;
        while (elapsed < resultTextFadeDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / Mathf.Max(0.01f, resultTextFadeDuration));
            if (resultMessageCanvasGroup != null)
            {
                resultMessageCanvasGroup.alpha = t;
            }
            yield return null;
        }

        if (resultMessageCanvasGroup != null)
        {
            resultMessageCanvasGroup.alpha = 1f;
        }

        yield return new WaitForSeconds(Mathf.Max(0f, resultMessageHoldDuration));

        elapsed = 0f;
        while (elapsed < resultFadeDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / Mathf.Max(0.01f, resultFadeDuration));

            if (resultFadeOverlay != null)
            {
                Color fadeColor = resultFadeOverlay.color;
                fadeColor.a = t;
                resultFadeOverlay.color = fadeColor;
            }

            if (resultMessageCanvasGroup != null)
            {
                resultMessageCanvasGroup.alpha = 1f - (t * 0.35f);
            }

            yield return null;
        }

        SceneTransitionManager.TransitionToScene(destinationSceneName, TransitionType.CircleIris);
    }

    private void EnsureResultOverlayUI()
    {
        Canvas parentCanvas = ResolveBattleCanvas();
        if (parentCanvas == null)
        {
            return;
        }

        Transform overlayRoot = parentCanvas.transform.Find("BattleResultOverlay");
        if (overlayRoot == null)
        {
            GameObject overlayRootObject = new GameObject("BattleResultOverlay", typeof(RectTransform));
            overlayRoot = overlayRootObject.transform;
            overlayRoot.SetParent(parentCanvas.transform, false);

            RectTransform rootRect = overlayRoot.GetComponent<RectTransform>();
            rootRect.anchorMin = Vector2.zero;
            rootRect.anchorMax = Vector2.one;
            rootRect.offsetMin = Vector2.zero;
            rootRect.offsetMax = Vector2.zero;
        }

        if (resultFadeOverlay == null)
        {
            Transform fadeTransform = overlayRoot.Find("FadeOverlay");
            if (fadeTransform == null)
            {
                GameObject fadeObject = new GameObject("FadeOverlay", typeof(RectTransform), typeof(Image));
                fadeTransform = fadeObject.transform;
                fadeTransform.SetParent(overlayRoot, false);

                RectTransform fadeRect = fadeObject.GetComponent<RectTransform>();
                fadeRect.anchorMin = Vector2.zero;
                fadeRect.anchorMax = Vector2.one;
                fadeRect.offsetMin = Vector2.zero;
                fadeRect.offsetMax = Vector2.zero;
            }

            resultFadeOverlay = fadeTransform.GetComponent<Image>();
            if (resultFadeOverlay == null)
            {
                resultFadeOverlay = fadeTransform.gameObject.AddComponent<Image>();
            }

            resultFadeOverlay.color = new Color(0f, 0f, 0f, 0f);
            resultFadeOverlay.raycastTarget = true;
        }

        if (resultMessageText == null || resultMessageCanvasGroup == null)
        {
            Transform textTransform = overlayRoot.Find("ResultMessage");
            if (textTransform == null)
            {
                GameObject textObject = new GameObject("ResultMessage", typeof(RectTransform), typeof(CanvasGroup), typeof(TextMeshProUGUI));
                textTransform = textObject.transform;
                textTransform.SetParent(overlayRoot, false);

                RectTransform textRect = textObject.GetComponent<RectTransform>();
                textRect.anchorMin = new Vector2(0.5f, 0.5f);
                textRect.anchorMax = new Vector2(0.5f, 0.5f);
                textRect.pivot = new Vector2(0.5f, 0.5f);
                textRect.sizeDelta = new Vector2(1280f, 240f);
                textRect.anchoredPosition = new Vector2(0f, 60f);
            }

            if (resultMessageCanvasGroup == null)
            {
                resultMessageCanvasGroup = textTransform.GetComponent<CanvasGroup>();
                if (resultMessageCanvasGroup == null)
                {
                    resultMessageCanvasGroup = textTransform.gameObject.AddComponent<CanvasGroup>();
                }
            }

            if (resultMessageText == null)
            {
                TextMeshProUGUI createdText = textTransform.GetComponent<TextMeshProUGUI>();
                if (createdText == null)
                {
                    createdText = textTransform.gameObject.AddComponent<TextMeshProUGUI>();
                }

                TMP_Text templateText = ResolveResultTextTemplate();
                if (templateText != null)
                {
                    createdText.font = templateText.font;
                    createdText.fontSharedMaterial = templateText.fontSharedMaterial;
                }

                createdText.alignment = TextAlignmentOptions.Center;
                createdText.fontSize = 72f;
                createdText.enableWordWrapping = false;
                createdText.text = string.Empty;
                createdText.color = Color.white;
                resultMessageText = createdText;
            }
        }

        if (resultMessageCanvasGroup != null)
        {
            resultMessageCanvasGroup.alpha = 0f;
            resultMessageCanvasGroup.interactable = false;
            resultMessageCanvasGroup.blocksRaycasts = false;
        }
    }

    private Canvas ResolveBattleCanvas()
    {
        if (battleUIController != null)
        {
            Canvas uiCanvas = battleUIController.GetComponentInParent<Canvas>();
            if (uiCanvas != null)
            {
                return uiCanvas.rootCanvas != null ? uiCanvas.rootCanvas : uiCanvas;
            }
        }

        if (boardParent != null)
        {
            Canvas boardCanvas = boardParent.GetComponentInParent<Canvas>();
            if (boardCanvas != null)
            {
                return boardCanvas.rootCanvas != null ? boardCanvas.rootCanvas : boardCanvas;
            }
        }

        return FindObjectOfType<Canvas>();
    }

    private void EnsureThemeChangeFadeOverlay()
    {
        if (themeChangeFadeOverlay != null)
        {
            Color overlayColor = themeChangeFadeOverlay.color;
            overlayColor.a = Mathf.Clamp01(overlayColor.a);
            themeChangeFadeOverlay.color = overlayColor;
            themeChangeFadeOverlay.raycastTarget = false;
            return;
        }

        Canvas parentCanvas = ResolveBattleCanvas();
        if (parentCanvas == null)
        {
            return;
        }

        Transform overlayTransform = parentCanvas.transform.Find("ThemeChangeFadeOverlay");
        if (overlayTransform == null)
        {
            GameObject overlayObject = new GameObject("ThemeChangeFadeOverlay", typeof(RectTransform), typeof(Image));
            overlayTransform = overlayObject.transform;
            overlayTransform.SetParent(parentCanvas.transform, false);

            RectTransform overlayRect = overlayObject.GetComponent<RectTransform>();
            overlayRect.anchorMin = Vector2.zero;
            overlayRect.anchorMax = Vector2.one;
            overlayRect.offsetMin = Vector2.zero;
            overlayRect.offsetMax = Vector2.zero;
        }

        themeChangeFadeOverlay = overlayTransform.GetComponent<Image>();
        if (themeChangeFadeOverlay == null)
        {
            themeChangeFadeOverlay = overlayTransform.gameObject.AddComponent<Image>();
        }

        themeChangeFadeOverlay.color = new Color(0f, 0f, 0f, 0f);
        themeChangeFadeOverlay.raycastTarget = false;
    }

    private TMP_Text ResolveResultTextTemplate()
    {
        if (battleUIController == null)
        {
            return null;
        }

        if (battleUIController.floorText != null) return battleUIController.floorText;
        if (battleUIController.encounterLabelText != null) return battleUIController.encounterLabelText;
        if (battleUIController.coinText != null) return battleUIController.coinText;
        return null;
    }

    public void RefreshPlayerExpUI()
    {
        if (battleUIController == null) return;
        if (playerUnit == null) return;

        PlayerProgression progression = playerUnit.GetComponent<PlayerProgression>();
        if (progression == null) return;

        float progress = progression.GetExpProgress01();
        battleUIController.SetPlayerExpBar(progress);

        Debug.Log($"[PanelBattleManager] ExpBar progress={progress}");
    }
}
