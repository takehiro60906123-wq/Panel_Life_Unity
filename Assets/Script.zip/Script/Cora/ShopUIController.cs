using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;

// ============================================
// ���XUI�R���g���[���[
//
// Inspector �ňȉ���ݒ�:
//   - shopPanel: ���X�S�̂̃��[�g�p�l���iCanvas ���� Panel�j
//   - shopSlots[3]: �e���i�X���b�g�̐ݒ�
//   - leaveButton: �u��������v�{�^��
//   - playerCoinsText: �����R�C���\��
//
// �yUnity ���ŕK�v�ȍ\���z
//   Canvas
//   ������ ShopPanel (��\���Ŕz�u)
//       ������ Title ("���X" �e�L�X�g)
//       ������ CoinsText ("����: 120G")
//       ������ Slot0
//       ��   ������ NameText
//       ��   ������ DescText
//       ��   ������ CostText
//       ��   ������ BuyButton
//       ������ Slot1 (����)
//       ������ Slot2 (����)
//       ������ LeaveButton ("��������")
// ============================================
public class ShopUIController : MonoBehaviour
{
    [Header("���X�p�l��")]
    [SerializeField] private GameObject shopPanel;
    [SerializeField] private CanvasGroup shopCanvasGroup;

    [Header("�����R�C��")]
    [SerializeField] private TMP_Text playerCoinsText;

    [Header("���i�X���b�g")]
    [SerializeField] private ShopSlotUI[] shopSlots;

    [Header("��������{�^��")]
    [SerializeField] private Button leaveButton;

    [Header("���o�ݒ�")]
    [SerializeField] private float fadeInDuration = 0.3f;
    [SerializeField] private float fadeOutDuration = 0.2f;

    private ShopController shopController;

    private void Start()
    {
        // �N�����͔�\��
        if (shopPanel != null)
        {
            shopPanel.SetActive(false);
        }

        if (leaveButton != null)
        {
            leaveButton.onClick.RemoveAllListeners();
            leaveButton.onClick.AddListener(OnClickLeave);
        }
    }

    // ============================================
    // ���X��\������
    // ============================================
    public void ShowShop(List<ShopItemData> offerings, ShopController controller)
    {
        shopController = controller;

        if (shopPanel != null)
        {
            shopPanel.SetActive(true);
        }

        // �t�F�[�h�C��
        if (shopCanvasGroup != null)
        {
            shopCanvasGroup.alpha = 0f;
            shopCanvasGroup.DOFade(1f, fadeInDuration).SetEase(Ease.OutQuad);
        }

        RefreshShop(offerings, controller);
    }

    // ============================================
    // ���X���\���ɂ���
    // ============================================
    public void HideShop()
    {
        if (shopCanvasGroup != null)
        {
            shopCanvasGroup.DOFade(0f, fadeOutDuration).SetEase(Ease.InQuad).OnComplete(() =>
            {
                if (shopPanel != null)
                {
                    shopPanel.SetActive(false);
                }
            });
        }
        else if (shopPanel != null)
        {
            shopPanel.SetActive(false);
        }

        shopController = null;
    }

    // ============================================
    // �\�����X�V����i�w����ɌĂ΂��j
    // ============================================
    public void RefreshShop(List<ShopItemData> offerings, ShopController controller)
    {
        shopController = controller;

        // �����R�C��
        if (playerCoinsText != null && controller != null)
        {
            playerCoinsText.text = $"����: {controller.GetCurrentCoins()}G";
        }

        // �e�X���b�g���X�V
        if (shopSlots == null) return;

        for (int i = 0; i < shopSlots.Length; i++)
        {
            if (shopSlots[i] == null) continue;

            ShopItemData item = (offerings != null && i < offerings.Count) ? offerings[i] : null;
            bool canBuy = controller != null && controller.CanPurchase(i);

            shopSlots[i].SetItem(item, canBuy, i, OnClickBuy);
        }
    }

    // ============================================
    // �u�w���v�{�^������
    // ============================================
    private void OnClickBuy(int slotIndex)
    {
        if (shopController == null) return;

        bool success = shopController.TryPurchase(slotIndex);
        if (!success) return;

        // �w�������̃t�B�[�h�o�b�N
        if (shopSlots != null && slotIndex >= 0 && slotIndex < shopSlots.Length)
        {
            shopSlots[slotIndex].PlayPurchasedFeedback();
        }
    }

    // ============================================
    // �u��������v�{�^������
    // ============================================
    private void OnClickLeave()
    {
        if (shopController != null)
        {
            shopController.CloseShop();
        }
    }

    public bool IsShopOpen => shopPanel != null && shopPanel.activeSelf;
}

// ============================================
// ���i�X���b�g1����UI�Q��
// ============================================
[System.Serializable]
public class ShopSlotUI
{
    public GameObject slotRoot;
    public TMP_Text nameText;
    public TMP_Text descriptionText;
    public TMP_Text costText;
    public Button buyButton;
    public Image iconImage;

    [Header("�F�ݒ�")]
    public Color affordableColor = Color.white;
    public Color tooExpensiveColor = new Color(1f, 0.4f, 0.4f);
    public Color soldOutColor = new Color(0.5f, 0.5f, 0.5f);

    public void SetItem(ShopItemData item, bool canBuy, int index, System.Action<int> onBuy)
    {
        if (slotRoot == null) return;

        // SOLD OUT or ��X���b�g
        if (item == null)
        {
            if (nameText != null) nameText.text = "SOLD OUT";
            if (descriptionText != null) descriptionText.text = "";
            if (costText != null) costText.text = "";
            if (buyButton != null) buyButton.interactable = false;
            ApplyColor(soldOutColor);
            return;
        }

        // ���i��
        if (nameText != null)
        {
            string categoryTag = GetCategoryTag(item.category);
            nameText.text = $"{categoryTag} {item.itemName}";
        }

        // ����
        if (descriptionText != null)
        {
            descriptionText.text = item.description;
        }

        // ���i
        if (costText != null)
        {
            costText.text = $"{item.cost}G";
        }

        // �w���{�^��
        if (buyButton != null)
        {
            buyButton.onClick.RemoveAllListeners();
            int capturedIndex = index;
            buyButton.onClick.AddListener(() => onBuy?.Invoke(capturedIndex));
            buyButton.interactable = canBuy;
        }

        ApplyColor(canBuy ? affordableColor : tooExpensiveColor);
    }

    public void PlayPurchasedFeedback()
    {
        if (slotRoot == null) return;

        RectTransform rect = slotRoot.GetComponent<RectTransform>();
        if (rect != null)
        {
            rect.DOKill();
            rect.localScale = Vector3.one;
            rect.DOPunchScale(new Vector3(0.1f, 0.1f, 0f), 0.25f, 6, 0.8f);
        }

        if (nameText != null)
        {
            nameText.text = "SOLD OUT";
        }
        if (descriptionText != null)
        {
            descriptionText.text = "�w���ς�";
        }
        if (costText != null)
        {
            costText.text = "";
        }
        if (buyButton != null)
        {
            buyButton.interactable = false;
        }

        ApplyColor(soldOutColor);
    }

    private void ApplyColor(Color color)
    {
        if (nameText != null) nameText.color = color;
        if (costText != null) costText.color = color;
    }

    private string GetCategoryTag(ShopItemCategory category)
    {
        switch (category)
        {
            case ShopItemCategory.Weapon: return "[����]";
            case ShopItemCategory.Gun: return "[�e]";
            case ShopItemCategory.Consumable: return "[���Օi]";
            case ShopItemCategory.HealHP: return "[��]";
            default: return "";
        }
    }
}