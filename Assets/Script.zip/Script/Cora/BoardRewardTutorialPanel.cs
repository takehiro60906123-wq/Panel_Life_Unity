using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BoardRewardTutorialPanel : MonoBehaviour
{
    [SerializeField] private GameObject rootObject;
    [SerializeField] private CanvasGroup canvasGroup;
    [SerializeField] private TMP_Text titleText;
    [SerializeField] private TMP_Text bodyText;
    [SerializeField] private Button confirmButton;
    [SerializeField] private TMP_Text confirmButtonText;
    [SerializeField] private string defaultConfirmText = "了解";

    private Action onConfirm;

    private void Awake()
    {
        if (confirmButton != null)
        {
            confirmButton.onClick.RemoveListener(HandleConfirmClicked);
            confirmButton.onClick.AddListener(HandleConfirmClicked);
        }

        HideImmediate();
    }

    private void OnDestroy()
    {
        if (confirmButton != null)
        {
            confirmButton.onClick.RemoveListener(HandleConfirmClicked);
        }
    }

    public void Show(string title, string body, Action onConfirm)
    {
        this.onConfirm = onConfirm;

        GameObject targetRoot = rootObject != null ? rootObject : gameObject;
        targetRoot.SetActive(true);

        if (titleText != null)
        {
            titleText.text = string.IsNullOrEmpty(title) ? string.Empty : title;
        }

        if (bodyText != null)
        {
            bodyText.text = string.IsNullOrEmpty(body) ? string.Empty : body;
        }

        if (confirmButtonText != null)
        {
            confirmButtonText.text = string.IsNullOrEmpty(defaultConfirmText) ? "OK" : defaultConfirmText;
        }

        if (canvasGroup != null)
        {
            canvasGroup.alpha = 1f;
            canvasGroup.interactable = true;
            canvasGroup.blocksRaycasts = true;
        }
    }

    public void Hide()
    {
        onConfirm = null;

        GameObject targetRoot = rootObject != null ? rootObject : gameObject;

        if (canvasGroup != null)
        {
            canvasGroup.alpha = 0f;
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;
        }

        targetRoot.SetActive(false);
    }

    public void HideImmediate()
    {
        Hide();
    }

    private void HandleConfirmClicked()
    {
        Action callback = onConfirm;
        Hide();
        callback?.Invoke();
    }
}
