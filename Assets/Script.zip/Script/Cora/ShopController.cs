﻿using System;
using System.Collections.Generic;
using UnityEngine;

// ============================================
// ���X�R���g���[���[
// �i���������E�w�������E�����ύX���Ǘ�����B
//
// PanelBattleManager ����Q�Ƃ��A
// EncounterFlowController �����X�����ɓ������Ƃ���
// OpenShop() ���ĂԁB
// ============================================
public class ShopController : MonoBehaviour
{
    [Header("���X�ݒ�")]
    [Tooltip("��x�ɒ񂷂鏤�i��")]
    [SerializeField] private int offeringCount = 3;

    [Header("�A�g")]
    [SerializeField] private PlayerCombatController playerCombatController;
    [SerializeField] private BattleInventoryController battleInventoryController;
    [SerializeField] private BattleUnit playerUnit;
    [SerializeField] private BattleUIController battleUIController;
    [SerializeField] private ShopUIController shopUIController;
    [SerializeField] private BattleItemIconDatabase battleItemIconDatabase;

    private List<ShopItemData> catalog;
    private List<ShopItemData> currentOfferings = new List<ShopItemData>();

    // �R�C���Q�Ɨp�R�[���o�b�N�iPanelBattleManager ����ݒ�j
    private Func<int> getCoins;
    private Action<int> addCoins;

    // ���X�I�����R�[���o�b�N
    private Action onShopClosed;

    [SerializeField] private GunDefinition pistolDefinition;
    [SerializeField] private GunDefinition machineGunDefinition;
    [SerializeField] private GunDefinition shotgunDefinition;
    [SerializeField] private GunDefinition rifleDefinition;

    private GunDefinition GetGunDefinition(GunType gunType)
    {
        switch (gunType)
        {
            case GunType.Pistol: return pistolDefinition;
            case GunType.MachineGun: return machineGunDefinition;
            case GunType.Shotgun: return shotgunDefinition;
            case GunType.Rifle: return rifleDefinition;
            default: return null;
        }
    }

    private void Awake()
    {
        catalog = ShopItemData.CreateDefaultCatalog();
    }

    // ============================================
    // �������iPanelBattleManager / Bootstrapper ����Ăԁj
    // ============================================
    public void Initialize(
        PlayerCombatController playerCombatController,
        BattleInventoryController battleInventoryController,
        BattleUnit playerUnit,
        BattleUIController battleUIController,
        BattleItemIconDatabase battleItemIconDatabase,
        Func<int> getCoins,
        Action<int> addCoins)
    {
        this.playerCombatController = playerCombatController;
        this.battleInventoryController = battleInventoryController;
        this.playerUnit = playerUnit;
        this.battleUIController = battleUIController;
        this.battleItemIconDatabase = battleItemIconDatabase;
        this.getCoins = getCoins;
        this.addCoins = addCoins;
    }

    // ============================================
    // ���X���J��
    // ============================================
    public void OpenShop(Action onClosed)
    {
        onShopClosed = onClosed;
        GenerateOfferings();

        if (shopUIController != null)
        {
            shopUIController.ShowShop(currentOfferings, this);
        }
    }

    // ============================================
    // ���X�����iUI�́u��������v�{�^������Ă΂��j
    // ============================================
    public void CloseShop()
    {
        if (shopUIController != null)
        {
            shopUIController.HideShop();
        }

        onShopClosed?.Invoke();
        onShopClosed = null;
    }

    // ============================================
    // �i�����������_������
    // ============================================
    private void GenerateOfferings()
    {
        currentOfferings.Clear();

        if (catalog == null || catalog.Count == 0) return;

        // �J�^���O���V���b�t�����Đ擪������
        List<ShopItemData> shuffled = new List<ShopItemData>(catalog);
        for (int i = shuffled.Count - 1; i > 0; i--)
        {
            int j = UnityEngine.Random.Range(0, i + 1);
            ShopItemData temp = shuffled[i];
            shuffled[i] = shuffled[j];
            shuffled[j] = temp;
        }

        // �w���\�Ȍ����t�B���^�i���Ɏ����Ă��镐��/�e�͏��O�j
        foreach (ShopItemData item in shuffled)
        {
            if (currentOfferings.Count >= offeringCount) break;
            if (ShouldExcludeFromOffering(item)) continue;

            currentOfferings.Add(item);
        }
    }

    // ============================================
    // ���ɑ������̕���/�e�͒񂵂Ȃ�
    // ============================================
    private bool ShouldExcludeFromOffering(ShopItemData item)
    {
        if (item == null) return true;
        if (playerCombatController == null) return false;

        if (item.category == ShopItemCategory.Weapon)
        {
            WeaponData current = playerCombatController.loadout?.meleeWeapon;
            if (current != null && current.weaponType == item.weaponType)
            {
                return true;
            }
        }

        if (item.category == ShopItemCategory.Gun)
        {
            GunData current = playerCombatController.GetGunData();
            if (current != null && current.gunType == item.gunType)
            {
                return true;
            }
        }

        // HP�S���Ȃ�񕜌n�����O
        if (item.category == ShopItemCategory.HealHP)
        {
            if (playerUnit != null && playerUnit.CurrentHP >= playerUnit.maxHP)
            {
                return true;
            }
        }

        // �C���x���g�����t�Ȃ���Օi�����O
        if (item.category == ShopItemCategory.Consumable)
        {
            if (battleInventoryController != null && battleInventoryController.FreeSlots <= 0)
            {
                return true;
            }
        }

        return false;
    }

    // ============================================
    // �w���\���ǂ����̔���
    // ============================================
    public bool CanPurchase(int offeringIndex)
    {
        if (offeringIndex < 0 || offeringIndex >= currentOfferings.Count) return false;

        ShopItemData item = currentOfferings[offeringIndex];
        if (item == null) return false;

        int coins = getCoins != null ? getCoins() : 0;
        if (coins < item.cost) return false;

        // ���Օi�̏ꍇ�A�C���x���g���ɋ󂫂����邩
        if (item.category == ShopItemCategory.Consumable)
        {
            if (battleInventoryController == null || battleInventoryController.FreeSlots <= 0)
            {
                return false;
            }
        }

        // HP�񕜂̏ꍇ�A�S���łȂ���
        if (item.category == ShopItemCategory.HealHP)
        {
            if (playerUnit == null) return false;
            if (playerUnit.CurrentHP >= playerUnit.maxHP) return false;
        }

        return true;
    }

    // ============================================
    // �w�����s
    // ============================================
    public bool TryPurchase(int offeringIndex)
    {
        if (!CanPurchase(offeringIndex)) return false;

        ShopItemData item = currentOfferings[offeringIndex];

        // �R�C������
        addCoins?.Invoke(-item.cost);

        // ���ʓK�p
        ApplyPurchase(item);

        // �w���ς݂̏��i��񂩂珜���iSOLD OUT�j
        currentOfferings[offeringIndex] = null;

        // UI �X�V
        if (shopUIController != null)
        {
            shopUIController.RefreshShop(currentOfferings, this);
        }

        if (battleUIController != null)
        {
            battleUIController.RefreshGunUI();
            battleUIController.RefreshInventoryUI();
        }

        return true;
    }

    // ============================================
    // �w�����ʂ̓K�p
    // ============================================
    private void ApplyPurchase(ShopItemData item)
    {
        if (item == null) return;

        switch (item.category)
        {
            case ShopItemCategory.Weapon:
                ApplyWeaponPurchase(item);
                break;

            case ShopItemCategory.Gun:
                ApplyGunPurchase(item);
                break;

            case ShopItemCategory.Consumable:
                ApplyConsumablePurchase(item);
                break;

            case ShopItemCategory.HealHP:
                ApplyHealPurchase(item);
                break;
        }
    }

    private void ApplyWeaponPurchase(ShopItemData item)
    {
        if (playerCombatController == null) return;

        switch (item.weaponType)
        {
            case WeaponType.Sword:
                playerCombatController.EquipSword();
                break;
            case WeaponType.GreatSword:
                playerCombatController.EquipGreatSword();
                break;
        }
    }

    private void ApplyGunPurchase(ShopItemData item)
    {
        if (playerCombatController == null) return;
        if (playerCombatController.loadout == null) return;

        GunDefinition def = GetGunDefinition(item.gunType);
        if (def != null)
        {
            playerCombatController.loadout.gun = def.ToGunData();
        }
        else
        {
            playerCombatController.loadout.gun = CreateGunData(item.gunType);
        }
    }

    private void ApplyConsumablePurchase(ShopItemData item)
    {
        if (battleInventoryController == null) return;

        BattleItemData battleItem = battleItemIconDatabase != null
            ? battleItemIconDatabase.CreatePreset(item.consumableType)
            : BattleItemData.CreatePreset(item.consumableType);

        if (battleItem != null)
        {
            battleInventoryController.TryAddItem(battleItem);
        }
    }

    private void ApplyHealPurchase(ShopItemData item)
    {
        if (playerUnit == null) return;

        int heal = item.healAmount;
        if (heal >= 999)
        {
            heal = playerUnit.maxHP - playerUnit.CurrentHP;
        }

        playerUnit.Heal(heal);
    }

    // ============================================
    // GunData �����i����p�n�[�h�R�[�h�j
    // ������ ScriptableObject / GunDataCatalog �Ɉڍs
    // ============================================
    private GunData CreateGunData(GunType gunType)
    {
        switch (gunType)
        {
            case GunType.Pistol:
                return new GunData
                {
                    gunType = GunType.Pistol,
                    gunName = "�s�X�g��",
                    gaugeCost = 3,
                    shotCount = 2,
                    damagePerShot = 2,
                    useAllGauge = false,
                    minGaugeToFire = 3
                };

            case GunType.MachineGun:
                return new GunData
                {
                    gunType = GunType.MachineGun,
                    gunName = "�}�V���K��",
                    gaugeCost = 0,
                    shotCount = 1,
                    damagePerShot = 1,
                    useAllGauge = true,
                    minGaugeToFire = 3
                };

            case GunType.Shotgun:
                return new GunData
                {
                    gunType = GunType.Shotgun,
                    gunName = "�V���b�g�K��",
                    gaugeCost = 5,
                    shotCount = 3,
                    damagePerShot = 2,
                    useAllGauge = false,
                    minGaugeToFire = 5
                };

            case GunType.Rifle:
                return new GunData
                {
                    gunType = GunType.Rifle,
                    gunName = "���C�t��",
                    gaugeCost = 4,
                    shotCount = 1,
                    damagePerShot = 6,
                    useAllGauge = false,
                    minGaugeToFire = 4
                };
        }

        return null;
    }

    // ============================================
    // �O���A�N�Z�X
    // ============================================
    public IReadOnlyList<ShopItemData> CurrentOfferings => currentOfferings;
    public int GetCurrentCoins() => getCoins != null ? getCoins() : 0;
}